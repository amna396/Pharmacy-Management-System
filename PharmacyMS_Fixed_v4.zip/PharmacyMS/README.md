# 💊 CureWell Pharmacy Management System
### DBS26IST2ndAF – Semester Final Project

---

## ✅ What's Included

| File/Folder | Description |
|---|---|
| `SQL/pharmacy_db.sql` | Full MySQL database (run this first) |
| `CSharp/PharmacyMS.sln` | Visual Studio Solution — double-click to open |
| `CSharp/PharmacyMS/` | C# Windows Forms project |

---

## 🚀 SETUP STEPS (Do these in order)

### STEP 1 — Install MySQL
- Download MySQL Community Server from https://dev.mysql.com/downloads/
- Or use XAMPP (already includes MySQL)
- Make sure MySQL is **running** on port 3306

### STEP 2 — Create the Database
1. Open **MySQL Workbench** or **phpMyAdmin** or **MySQL Command Line**
2. Run the file: `SQL/pharmacy_db.sql`
3. This creates the `PharmacyMS` database with all tables, views, stored procedures, triggers, and sample data

### STEP 3 — Configure Connection
1. Open `CSharp/PharmacyMS/App.config`
2. Edit this line with your MySQL password:
```xml
<add name="PharmacyDB"
     connectionString="Server=localhost;Database=PharmacyMS;Uid=root;Pwd=YOUR_PASSWORD_HERE;..."
```

### STEP 4 — Open in Visual Studio
1. Double-click `CSharp/PharmacyMS.sln`
2. Visual Studio will open the project
3. Right-click the project → **Manage NuGet Packages**
4. Install these two packages:
   - `MySql.Data` (version 8.0.33)
   - `iTextSharp` (version 5.5.13.3)
5. Or open **Package Manager Console** and run:
```
Install-Package MySql.Data
Install-Package iTextSharp
```

### STEP 5 — Build & Run
1. Press **F5** or click **Start**
2. Login with:
   - Username: `admin`
   - Password: `Admin@123`

---

## 👤 Default Users

| Username | Password | Role |
|---|---|---|
| admin | Admin@123 | Admin |
| john_pharma | John@123 | Pharmacist |
| sara_mgr | Sara@123 | Manager |

---

## 📋 Project Requirements Checklist

| Requirement | Status |
|---|---|
| ✅ Minimum 8 domain classes | 11 classes (User, Medicine, Customer, Sale, SaleItem, Supplier, Category, Prescription, PurchaseOrder, Inventory, Returns) |
| ✅ Minimum 5 software classes | Session, Logger, Validator, PasswordHelper, DBConnection, AuthService, SaleService, ReportService |
| ✅ Minimum 10 ERD entities | 16 tables |
| ✅ Minimum 15 database tables | 16 tables |
| ✅ Validators | Validator.cs — all forms validated |
| ✅ Exception handling | Try/catch in every DAL + Logger |
| ✅ UI components | TextBox, Password, Radio, CheckBox, ComboBox, DatePicker, TextArea, ScrollBar, DataGridView, Buttons in table, Panels, File Menu |
| ✅ Error logging | Logger.cs → file + DB table |
| ✅ Transactions (3+) | SaleDAL.CreateSale, sp_ProcessSale, sp_ReceivePurchaseOrder |
| ✅ Views (5+) | 6 views: LowStock, DailySales, MedicineSales, ExpiringMedicines, CustomerHistory, POOverview |
| ✅ Stored Procedures (3+) | sp_ProcessSale, sp_ReceivePurchaseOrder, sp_MonthlySalesReport, sp_SearchMedicines |
| ✅ Triggers (2+) | trg_CheckStock, trg_Audit_Medicine_Update, trg_UpdateSaleTotal |
| ✅ Constraints (10+) | 15+ constraints across all tables |
| ✅ PDF Reports (10+) | Invoice, Daily, Monthly, Range, LowStock, Expiry, Performance, Inventory, Customer, PO, Supplier |
| ✅ Same form for Add & Edit | MedicineForm, CustomerForm, SupplierForm, UserForm |
| ✅ File menu on each screen | All forms have MenuStrip with File menu |

---

## 📁 Project Structure

```
PharmacyMS/
├── SQL/
│   └── pharmacy_db.sql          ← Run this in MySQL first
└── CSharp/
    ├── PharmacyMS.sln            ← Open this in Visual Studio
    └── PharmacyMS/
        ├── App.config            ← Edit DB password here
        ├── Program.cs
        ├── DAL/                  ← Database Access Layer
        │   ├── DBConnection.cs
        │   ├── UserDAL.cs
        │   ├── MedicineDAL.cs
        │   ├── CategorySupplierDAL.cs
        │   ├── CustomerDAL.cs
        │   ├── SaleDAL.cs
        │   └── PurchaseOrderDAL.cs
        ├── Models/
        │   └── Models.cs         ← All domain classes
        ├── Services/
        │   ├── Services.cs       ← AuthService, SaleService
        │   └── ReportService.cs  ← All PDF reports
        ├── Utils/
        │   ├── Logger.cs
        │   ├── Validator.cs
        │   └── PasswordHelper.cs
        └── Forms/
            ├── LoginForm.cs
            ├── DashboardForm.cs
            ├── MedicineForm.cs
            ├── SalesForm.cs
            ├── OtherForms.cs     ← Customer, Supplier, User, PO forms
            └── ReportFormFull.cs
```

---

## 🛠 Technologies

- **Frontend:** C# Windows Forms (.NET Framework 4.7.2)
- **Backend:** C# with DAL pattern
- **Database:** MySQL 8.0
- **PDF:** iTextSharp 5.5.13
- **IDE:** Visual Studio 2019/2022

---

*CureWell Pharmacy Management System — Semester Final Project*
