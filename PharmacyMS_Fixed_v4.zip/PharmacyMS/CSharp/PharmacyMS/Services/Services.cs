using System;
using PharmacyMS.DAL;
using PharmacyMS.Models;
using PharmacyMS.Utils;

namespace PharmacyMS.Services
{
    // ══════════════════════════════════════════════════════════════════════════
    //  AuthService
    // ══════════════════════════════════════════════════════════════════════════
    public class AuthService
    {
        private readonly UserDAL _userDAL = new UserDAL();

        /// <summary>Returns logged-in User or null.</summary>
        public User Login(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
                return null;

            string hash = PasswordHelper.Hash(password);
            var user = _userDAL.GetByUsernameAndPassword(username, hash);

            if (user != null)
            {
                Session.CurrentUser = user;
                _userDAL.UpdateLastLogin(user.UserID);
                Logger.LogInfo("AuthService", $"User '{username}' logged in.");
            }
            else
            {
                Logger.LogWarning("AuthService", $"Failed login attempt for '{username}'.");
            }

            return user;
        }

        public void Logout()
        {
            if (Session.IsLoggedIn)
                Logger.LogInfo("AuthService", $"User '{Session.CurrentUser.Username}' logged out.");
            Session.Clear();
        }

        public bool CanAccess(string requiredRole)
        {
            if (!Session.IsLoggedIn) return false;
            if (Session.HasRole("Admin")) return true;
            return Session.HasRole(requiredRole);
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SaleService  (business logic layer between Forms and DAL)
    // ══════════════════════════════════════════════════════════════════════════
    public class SaleService
    {
        private readonly SaleDAL _saleDAL = new SaleDAL();

        public int ProcessSale(Sale sale)
        {
            // Validate
            if (sale.Items == null || sale.Items.Count == 0)
                throw new Exception("Cannot process an empty sale.");

            decimal total = 0;
            foreach (var item in sale.Items)
            {
                if (item.Quantity <= 0)
                    throw new Exception($"Quantity must be > 0 for {item.MedicineName}");
                item.SubTotal = (item.UnitPrice * item.Quantity) - item.Discount;
                total += item.SubTotal;
            }

            sale.TotalAmount    = total;
            sale.NetAmount      = total - sale.DiscountAmount;
            sale.UserID         = Session.CurrentUser.UserID;

            if (sale.NetAmount < 0)
                throw new Exception("Discount cannot exceed total amount.");

            int saleID = _saleDAL.CreateSale(sale);
            Logger.LogInfo("SaleService", $"Sale #{saleID} processed. Total: {sale.NetAmount:C}");
            return saleID;
        }
    }
}
