using System;
using System.Windows.Forms;
using PharmacyMS.DAL;
using PharmacyMS.Forms;

namespace PharmacyMS
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Test DB connection before launching
            if (!DBConnection.Instance.TestConnection())
            {
                MessageBox.Show(
                    "Cannot connect to the database.\n\n" +
                    "Please check:\n" +
                    "  1. MySQL server is running\n" +
                    "  2. Connection string in App.config is correct\n" +
                    "  3. Database 'PharmacyMS' exists (run pharmacy_db.sql first)",
                    "Connection Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            Application.Run(new LoginForm());
        }
    }
}
