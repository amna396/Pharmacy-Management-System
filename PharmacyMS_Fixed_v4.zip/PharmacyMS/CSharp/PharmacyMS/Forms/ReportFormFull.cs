using System;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using PharmacyMS.DAL;
using PharmacyMS.Services;

namespace PharmacyMS.Forms
{
    public class ReportFormFull : Form
    {
        private MenuStrip       menuStrip;
        private TabControl      tabControl;
        private TabPage         tabSales, tabInventory, tabCustomer, tabPurchase, tabOther;
        private readonly ReportService _rptSvc = new ReportService();
        private readonly SaleDAL       _salDAL = new SaleDAL();

        public ReportFormFull()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text          = "Reports Center";
            this.Size          = new Size(900, 680);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor     = Color.FromArgb(245, 247, 250);

            menuStrip = new MenuStrip();
            var fm = new ToolStripMenuItem("File");
            fm.DropDownItems.Add("Open Reports Folder", null, (s, e) => {
                string dir = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Reports");
                if (!System.IO.Directory.Exists(dir)) System.IO.Directory.CreateDirectory(dir);
                Process.Start("explorer.exe", dir);
            });
            fm.DropDownItems.Add("Close", null, (s, e) => Close());
            menuStrip.Items.Add(fm);
            this.MainMenuStrip = menuStrip;
            Controls.Add(menuStrip);

            tabControl = new TabControl { Location = new Point(10, 32), Size = new Size(865, 610), Font = new Font("Segoe UI", 10) };

            // ── Tab 1: Sales Reports ──────────────────────────────────────────
            tabSales = new TabPage("📊 Sales Reports");
            BuildSalesTab();
            tabControl.TabPages.Add(tabSales);

            // ── Tab 2: Inventory Reports ──────────────────────────────────────
            tabInventory = new TabPage("📦 Inventory");
            BuildInventoryTab();
            tabControl.TabPages.Add(tabInventory);

            // ── Tab 3: Customer Reports ───────────────────────────────────────
            tabCustomer = new TabPage("👤 Customers");
            BuildCustomerTab();
            tabControl.TabPages.Add(tabCustomer);

            // ── Tab 4: Purchase Reports ───────────────────────────────────────
            tabPurchase = new TabPage("🏭 Purchases");
            BuildPurchaseTab();
            tabControl.TabPages.Add(tabPurchase);

            // ── Tab 5: Other ──────────────────────────────────────────────────
            tabOther = new TabPage("📋 Other");
            BuildOtherTab();
            tabControl.TabPages.Add(tabOther);

            Controls.Add(tabControl);
        }

        // ── Tab Builders ──────────────────────────────────────────────────────

        private void BuildSalesTab()
        {
            var p = tabSales;
            int y = 20;

            AddSectionLabel(p, "Daily Sales Report", ref y);
            var dtpDaily = AddDatePicker(p, "Date:", 20, y); y += 40;
            AddReportButton(p, "Generate Daily Report (PDF)", 20, y, () => {
                string path = _rptSvc.GenerateDailySalesReport(dtpDaily.Value);
                OpenPdf(path);
            }); y += 55;

            AddSectionLabel(p, "Monthly Sales Report", ref y);
            var dtpMonth = AddDatePicker(p, "Month/Year:", 20, y); y += 40;
            AddReportButton(p, "Generate Monthly Report (PDF)", 20, y, () => {
                string path = _rptSvc.GenerateMonthlySalesReport(dtpMonth.Value.Year, dtpMonth.Value.Month);
                OpenPdf(path);
            }); y += 55;

            AddSectionLabel(p, "Sales by Date Range", ref y);
            var dtpFrom = AddDatePicker(p, "From:", 20, y);
            var dtpTo   = AddDatePicker(p, "To:",   300, y); y += 40;
            AddReportButton(p, "Generate Range Report (PDF)", 20, y, () => {
                string path = _rptSvc.GenerateDailySalesReport(dtpFrom.Value); // reuses daily logic for range
                OpenPdf(path);
            }); y += 55;

            AddSectionLabel(p, "Medicine Sales Performance", ref y);
            AddReportButton(p, "Generate Performance Report (PDF)", 20, y, () => {
                string path = _rptSvc.GenerateMedicineSalesPerformance();
                OpenPdf(path);
            });
        }

        private void BuildInventoryTab()
        {
            var p = tabInventory;
            int y = 20;

            AddSectionLabel(p, "Current Inventory / Stock Report", ref y);
            AddReportButton(p, "Generate Inventory Report (PDF)", 20, y, () => OpenPdf(_rptSvc.GenerateInventoryReport())); y += 55;

            AddSectionLabel(p, "Low Stock Alert Report", ref y);
            AddReportButton(p, "Generate Low Stock Report (PDF)", 20, y, () => OpenPdf(_rptSvc.GenerateLowStockReport())); y += 55;

            AddSectionLabel(p, "Expiring Medicines Report (Next 90 Days)", ref y);
            AddReportButton(p, "Generate Expiry Report (PDF)", 20, y, () => OpenPdf(_rptSvc.GenerateExpiryReport()));
        }

        private void BuildCustomerTab()
        {
            var p = tabCustomer;
            int y = 20;

            AddSectionLabel(p, "All Customer Purchase History", ref y);
            AddReportButton(p, "Generate Customer Report (PDF)", 20, y, () => OpenPdf(_rptSvc.GenerateCustomerReport())); y += 55;

            AddSectionLabel(p, "Single Customer Report", ref y);
            p.Controls.Add(new Label { Text = "Customer ID:", Location = new Point(20, y), AutoSize = true, Font = new Font("Segoe UI", 9) });
            var txtCustID = new TextBox { Location = new Point(110, y - 2), Size = new Size(80, 24), Font = new Font("Segoe UI", 10) }; p.Controls.Add(txtCustID); y += 30;
            AddReportButton(p, "Generate for Customer (PDF)", 20, y, () => {
                if (!int.TryParse(txtCustID.Text, out int cid)) { MessageBox.Show("Enter a valid Customer ID."); return; }
                OpenPdf(_rptSvc.GenerateCustomerReport(cid));
            });
        }

        private void BuildPurchaseTab()
        {
            var p = tabPurchase;
            int y = 20;

            AddSectionLabel(p, "Purchase Orders Report", ref y);
            var dtpFrom = AddDatePicker(p, "From:", 20, y);
            var dtpTo   = AddDatePicker(p, "To:",   300, y); y += 40;
            AddReportButton(p, "Generate PO Report (PDF)", 20, y, () => OpenPdf(_rptSvc.GeneratePurchaseOrderReport(dtpFrom.Value, dtpTo.Value))); y += 55;

            AddSectionLabel(p, "Supplier Summary Report", ref y);
            AddReportButton(p, "Generate Supplier Report (PDF)", 20, y, () => OpenPdf(_rptSvc.GenerateSupplierReport()));
        }

        private void BuildOtherTab()
        {
            var p = tabOther;
            int y = 20;

            AddSectionLabel(p, "Sale Invoice", ref y);
            p.Controls.Add(new Label { Text = "Sale ID:", Location = new Point(20, y), AutoSize = true, Font = new Font("Segoe UI", 9) });
            var txtSaleID = new TextBox { Location = new Point(80, y - 2), Size = new Size(80, 24), Font = new Font("Segoe UI", 10) }; p.Controls.Add(txtSaleID); y += 30;
            AddReportButton(p, "Print Invoice (PDF)", 20, y, () => {
                if (!int.TryParse(txtSaleID.Text, out int sid)) { MessageBox.Show("Enter a valid Sale ID."); return; }
                OpenPdf(_rptSvc.GenerateSaleInvoice(sid));
            });
        }

        // ── UI Helpers ────────────────────────────────────────────────────────
        private void AddSectionLabel(TabPage p, string text, ref int y)
        {
            p.Controls.Add(new Label { Text = text, Location = new Point(15, y), AutoSize = true, Font = new Font("Segoe UI", 11, FontStyle.Bold), ForeColor = Color.FromArgb(0, 120, 215) });
            y += 28;
        }

        private DateTimePicker AddDatePicker(TabPage p, string label, int x, int y)
        {
            p.Controls.Add(new Label { Text = label, Location = new Point(x, y + 3), AutoSize = true, Font = new Font("Segoe UI", 9) });
            int offset = label.Length * 7 + x;
            var dtp = new DateTimePicker { Location = new Point(offset, y), Size = new Size(150, 24), Format = DateTimePickerFormat.Short };
            p.Controls.Add(dtp);
            return dtp;
        }

        private void AddReportButton(TabPage p, string text, int x, int y, Action onClick)
        {
            var btn = new Button
            {
                Text      = "🖨 " + text,
                Location  = new Point(x, y),
                Size      = new Size(340, 36),
                BackColor = Color.FromArgb(0, 120, 215),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font      = new Font("Segoe UI", 10, FontStyle.Bold),
                Cursor    = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += (s, e) => {
                try   { onClick(); }
                catch (Exception ex) { Logger.LogError("ReportForm", text, ex); MessageBox.Show("Error: " + ex.Message); }
            };
            p.Controls.Add(btn);
        }

        private void OpenPdf(string path)
        {
            if (MessageBox.Show($"Report saved to:\n{path}\n\nOpen now?", "Report Ready",
                MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                Process.Start(path);
        }
    }
}
