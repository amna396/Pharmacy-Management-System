using System;
using System.Drawing;
using System.Windows.Forms;
using PharmacyMS.DAL;
using PharmacyMS.Models;
using PharmacyMS.Services;

namespace PharmacyMS.Forms
{
    public class DashboardForm : Form
    {
        private MenuStrip        menuStrip;
        private Panel            pnlHeader, pnlStats;
        private Label            lblWelcome, lblDate;
        private Label            lblTodaySales, lblTodayRevenue, lblLowStock, lblTotalMeds;
        private TableLayoutPanel tblButtons;

        private readonly SaleDAL     _saleDAL = new SaleDAL();
        private readonly MedicineDAL _medDAL  = new MedicineDAL();
        private readonly AuthService _auth    = new AuthService();

        public DashboardForm()
        {
            InitializeComponent();
            LoadStats();
        }

        private void InitializeComponent()
        {
            this.Text            = "CureWell Pharmacy - Dashboard";
            this.Size            = new Size(1100, 700);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.BackColor       = Color.FromArgb(245, 247, 250);
            this.FormBorderStyle = FormBorderStyle.Sizable;

            // Menu Strip
            menuStrip = new MenuStrip { BackColor = Color.FromArgb(0, 120, 215), ForeColor = Color.White };

            var fileMenu = new ToolStripMenuItem("File") { ForeColor = Color.White };
            fileMenu.DropDownItems.Add("Dashboard",       null, (s, e) => LoadStats());
            fileMenu.DropDownItems.Add(new ToolStripSeparator());
            fileMenu.DropDownItems.Add("Change Password", null, (s, e) => DoChangePassword());
            fileMenu.DropDownItems.Add(new ToolStripSeparator());
            fileMenu.DropDownItems.Add("Logout",          null, (s, e) => DoLogout());
            fileMenu.DropDownItems.Add("Exit",            null, (s, e) => Application.Exit());

            var masterMenu = new ToolStripMenuItem("Master") { ForeColor = Color.White };
            masterMenu.DropDownItems.Add("Medicines",  null, (s, e) => OpenForm(new MedicineForm()));
            masterMenu.DropDownItems.Add("Suppliers",  null, (s, e) => OpenForm(new SupplierForm()));
            masterMenu.DropDownItems.Add("Customers",  null, (s, e) => OpenForm(new CustomerForm()));

            var transMenu = new ToolStripMenuItem("Transactions") { ForeColor = Color.White };
            transMenu.DropDownItems.Add("New Sale",        null, (s, e) => OpenForm(new SalesForm()));
            transMenu.DropDownItems.Add("Purchase Orders", null, (s, e) => OpenForm(new PurchaseOrderForm()));

            var adminMenu = new ToolStripMenuItem("Admin") { ForeColor = Color.White };
            adminMenu.DropDownItems.Add("Users", null, (s, e) => {
                if (!Session.HasRole("Admin")) {
                    MessageBox.Show("Access Denied.", "Security", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                OpenForm(new UserForm());
            });

            var rptMenu = new ToolStripMenuItem("Reports") { ForeColor = Color.White };
            rptMenu.DropDownItems.Add("Reports Center", null, (s, e) => OpenForm(new ReportFormFull()));

            menuStrip.Items.AddRange(new ToolStripItem[] { fileMenu, masterMenu, transMenu, adminMenu, rptMenu });
            this.MainMenuStrip = menuStrip;
            this.Controls.Add(menuStrip);

            // Header Panel
            pnlHeader = new Panel { Dock = DockStyle.Top, Height = 70, BackColor = Color.FromArgb(0, 120, 215) };
            lblWelcome = new Label
            {
                Text      = "Welcome, " + (Session.CurrentUser != null ? Session.CurrentUser.FullName : "") + "  (" + Session.CurrentRole + ")",
                Font      = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.White,
                Location  = new Point(20, 20),
                AutoSize  = true
            };
            lblDate = new Label
            {
                Text      = DateTime.Now.ToString("dddd, MMMM dd, yyyy"),
                Font      = new Font("Segoe UI", 10),
                ForeColor = Color.LightCyan,
                Location  = new Point(820, 25),
                AutoSize  = true
            };
            pnlHeader.Controls.AddRange(new Control[] { lblWelcome, lblDate });
            this.Controls.Add(pnlHeader);

            // Stats Panel
            pnlStats = new Panel { Location = new Point(20, 120), Size = new Size(1050, 100), BackColor = Color.Transparent };
            lblTodaySales   = CreateStatCard("Today's Sales",   "0",    Color.FromArgb(0,   120, 215), new Point(0,   0));
            lblTodayRevenue = CreateStatCard("Today's Revenue", "Rs 0", Color.FromArgb(0,   163, 136), new Point(260, 0));
            lblLowStock     = CreateStatCard("Low Stock Items", "0",    Color.FromArgb(220, 53,  69),  new Point(520, 0));
            lblTotalMeds    = CreateStatCard("Total Medicines", "0",    Color.FromArgb(108, 117, 125), new Point(780, 0));
            this.Controls.Add(pnlStats);

            // Quick Access label
            var lblQuick = new Label { Text = "Quick Access", Font = new Font("Segoe UI", 12, FontStyle.Bold), Location = new Point(20, 240), AutoSize = true };
            this.Controls.Add(lblQuick);

            // Navigation buttons
            tblButtons = new TableLayoutPanel
            {
                Location    = new Point(20, 270),
                Size        = new Size(1050, 320),
                ColumnCount = 4,
                RowCount    = 2,
                BackColor   = Color.Transparent
            };
            tblButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            tblButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            tblButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            tblButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));

            tblButtons.Controls.Add(CreateNavButton("Medicines",       Color.FromArgb(0,   120, 215), () => OpenForm(new MedicineForm())),      0, 0);
            tblButtons.Controls.Add(CreateNavButton("New Sale",        Color.FromArgb(0,   163, 136), () => OpenForm(new SalesForm())),         1, 0);
            tblButtons.Controls.Add(CreateNavButton("Customers",       Color.FromArgb(255, 193, 7),   () => OpenForm(new CustomerForm())),      2, 0);
            tblButtons.Controls.Add(CreateNavButton("Suppliers",       Color.FromArgb(108, 117, 125), () => OpenForm(new SupplierForm())),      3, 0);
            tblButtons.Controls.Add(CreateNavButton("Purchase Orders", Color.FromArgb(102, 16,  242), () => OpenForm(new PurchaseOrderForm())), 0, 1);
            tblButtons.Controls.Add(CreateNavButton("Users",           Color.FromArgb(220, 53,  69),  () => OpenForm(new UserForm())),          1, 1);
            tblButtons.Controls.Add(CreateNavButton("Reports",         Color.FromArgb(23,  162, 184), () => OpenForm(new ReportFormFull())),    2, 1);
            tblButtons.Controls.Add(CreateNavButton("Logout",          Color.FromArgb(52,  58,  64),  () => DoLogout()),                       3, 1);

            this.Controls.Add(tblButtons);
        }

        private Label CreateStatCard(string title, string value, Color color, Point loc)
        {
            var card = new Panel { Location = loc, Size = new Size(240, 90), BackColor = color };
            var t = new Label { Text = title, Font = new Font("Segoe UI", 9), ForeColor = Color.White, Location = new Point(10, 10), AutoSize = true };
            var v = new Label { Text = value, Font = new Font("Segoe UI", 22, FontStyle.Bold), ForeColor = Color.White, Location = new Point(10, 30), AutoSize = true };
            card.Controls.AddRange(new Control[] { t, v });
            pnlStats.Controls.Add(card);
            return v;
        }

        private Button CreateNavButton(string text, Color color, Action onClick)
        {
            var btn = new Button
            {
                Text      = text,
                Font      = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = color,
                FlatStyle = FlatStyle.Flat,
                Dock      = DockStyle.Fill,
                Margin    = new Padding(8),
                Cursor    = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += (s, e) => onClick();
            return btn;
        }

        private void LoadStats()
        {
            try
            {
                var summary = _saleDAL.GetTodaySummary();
                lblTodaySales.Text   = summary.Item1.ToString();
                lblTodayRevenue.Text = "Rs " + summary.Item2.ToString("N0");

                var lowStock = _medDAL.GetLowStock();
                lblLowStock.Text = lowStock.Rows.Count.ToString();

                var all = _medDAL.GetAll();
                lblTotalMeds.Text = all.Count.ToString();
            }
            catch (Exception ex)
            {
                Logger.LogError("DashboardForm", "LoadStats", ex);
            }
        }

        private void OpenForm(Form form)
        {
            form.StartPosition = FormStartPosition.CenterScreen;
            form.ShowDialog();
            LoadStats();
        }

        private void DoLogout()
        {
            if (MessageBox.Show("Are you sure you want to logout?", "Logout",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _auth.Logout();
                this.Close();
            }
        }

        private void DoChangePassword()
        {
            var newPass = Microsoft.VisualBasic.Interaction.InputBox(
                "Enter new password (min 6 chars, 1 uppercase, 1 digit):",
                "Change Password", "");
            if (string.IsNullOrWhiteSpace(newPass)) return;
            if (!PharmacyMS.Utils.Validator.IsStrongPassword(newPass))
            {
                MessageBox.Show("Weak password. Use at least 6 chars, 1 uppercase and 1 digit.",
                    "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var dal = new UserDAL();
            dal.ChangePassword(Session.CurrentUser.UserID, PharmacyMS.Utils.PasswordHelper.Hash(newPass));
            MessageBox.Show("Password changed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
