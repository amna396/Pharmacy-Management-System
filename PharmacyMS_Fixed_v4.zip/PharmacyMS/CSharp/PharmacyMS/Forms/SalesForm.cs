using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using PharmacyMS.DAL;
using PharmacyMS.Models;
using PharmacyMS.Services;
using PharmacyMS.Utils;

namespace PharmacyMS.Forms
{
    public class SalesForm : Form
    {
        // ── Controls ──────────────────────────────────────────────────────────
        private MenuStrip   menuStrip;
        private Panel       pnlLeft, pnlRight;
        // Left – Medicine search
        private TextBox     txtMedSearch;
        private DataGridView dgvMedicines;
        private NumericUpDown nudQty;
        private Button      btnAddItem;
        // Right – Cart
        private Label       lblCustomer, lblTotal, lblNet;
        private ComboBox    cboCustomer, cboPayment;
        private TextBox     txtDiscount, txtNotes;
        private DataGridView dgvCart;
        private Button      btnCheckout, btnClear, btnNewCustomer;
        private CheckBox    chkHasPrescription;

        private readonly MedicineDAL  _medDAL  = new MedicineDAL();
        private readonly CustomerDAL  _custDAL = new CustomerDAL();
        private readonly SaleService  _saleService = new SaleService();
        private readonly List<SaleItem> _cartItems = new List<SaleItem>();

        public SalesForm()
        {
            InitializeComponent();
            LoadMedicines();
            LoadCustomers();
        }

        private void InitializeComponent()
        {
            this.Text          = "New Sale – Point of Sale";
            this.Size          = new Size(1200, 720);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor     = Color.FromArgb(245, 247, 250);

            // ── Menu ──────────────────────────────────────────────────────────
            menuStrip = new MenuStrip();
            var fileMenu = new ToolStripMenuItem("File");
            fileMenu.DropDownItems.Add("Clear Cart", null, (s, e) => ClearCart());
            fileMenu.DropDownItems.Add(new ToolStripSeparator());
            fileMenu.DropDownItems.Add("Close",      null, (s, e) => this.Close());
            menuStrip.Items.Add(fileMenu);
            this.MainMenuStrip = menuStrip;
            this.Controls.Add(menuStrip);

            // ── Left Panel – Medicine List ─────────────────────────────────
            pnlLeft = new Panel { Location = new Point(10, 35), Size = new Size(580, 650), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };

            var lblSearch = new Label { Text = "Search Medicine:", Location = new Point(10, 12), AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            txtMedSearch  = new TextBox { Location = new Point(140, 10), Size = new Size(280, 26), Font = new Font("Segoe UI", 10) };
            txtMedSearch.TextChanged += (s, e) => LoadMedicines(txtMedSearch.Text);

            dgvMedicines = new DataGridView
            {
                Location = new Point(5, 45), Size = new Size(565, 450),
                ReadOnly = true, MultiSelect = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AllowUserToAddRows = false, BackgroundColor = Color.White, RowHeadersVisible = false,
                Font = new Font("Segoe UI", 9),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            dgvMedicines.Columns.Add("MedID",   "ID");
            dgvMedicines.Columns.Add("Name",     "Medicine");
            dgvMedicines.Columns.Add("Generic",  "Generic");
            dgvMedicines.Columns.Add("Price",    "Price");
            dgvMedicines.Columns.Add("Stock",    "In Stock");
            dgvMedicines.Columns.Add("Unit",     "Unit");
            dgvMedicines.Columns["MedID"].Visible = false;

            var lblQty = new Label { Text = "Quantity:", Location = new Point(10, 510), AutoSize = true, Font = new Font("Segoe UI", 10) };
            nudQty = new NumericUpDown { Location = new Point(90, 507), Size = new Size(80, 26), Minimum = 1, Maximum = 9999, Value = 1, Font = new Font("Segoe UI", 10) };
            btnAddItem = new Button
            {
                Text = "Add to Cart ➕", Location = new Point(185, 505), Size = new Size(150, 32),
                BackColor = Color.FromArgb(0, 163, 136), ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold), Cursor = Cursors.Hand
            };
            btnAddItem.Click += BtnAddItem_Click;

            pnlLeft.Controls.AddRange(new Control[] { lblSearch, txtMedSearch, dgvMedicines, lblQty, nudQty, btnAddItem });
            this.Controls.Add(pnlLeft);

            // ── Right Panel – Cart ─────────────────────────────────────────
            pnlRight = new Panel { Location = new Point(600, 35), Size = new Size(580, 650), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };

            var lblCartTitle = new Label { Text = "🛒 Shopping Cart", Location = new Point(10, 10), AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Bold) };

            lblCustomer = new Label { Text = "Customer:", Location = new Point(10, 45), AutoSize = true, Font = new Font("Segoe UI", 9) };
            cboCustomer = new ComboBox { Location = new Point(10, 65), Size = new Size(320, 26), Font = new Font("Segoe UI", 9), DropDownStyle = ComboBoxStyle.DropDownList };
            btnNewCustomer = new Button { Text = "+New", Location = new Point(340, 63), Size = new Size(60, 28), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(0,120,215), ForeColor = Color.White };
            btnNewCustomer.Click += (s, e) => { new CustomerForm().ShowDialog(); LoadCustomers(); };

            chkHasPrescription = new CheckBox { Text = "Has Prescription", Location = new Point(10, 100), AutoSize = true, Font = new Font("Segoe UI", 9) };

            dgvCart = new DataGridView
            {
                Location = new Point(5, 125), Size = new Size(565, 280),
                ReadOnly = false, MultiSelect = false, AllowUserToAddRows = false,
                BackgroundColor = Color.White, RowHeadersVisible = false, Font = new Font("Segoe UI", 9),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };
            dgvCart.Columns.Add("CartMedID",   "MedID");
            dgvCart.Columns.Add("CartName",    "Medicine");
            dgvCart.Columns.Add("CartQty",     "Qty");
            dgvCart.Columns.Add("CartPrice",   "Unit Price");
            dgvCart.Columns.Add("CartSub",     "SubTotal");
            dgvCart.Columns["CartMedID"].Visible = false;
            var colRemove = new DataGridViewButtonColumn { HeaderText = "Remove", Text = "✕", UseColumnTextForButtonValue = true, Width = 55 };
            dgvCart.Columns.Add(colRemove);
            dgvCart.CellClick += DgvCart_CellClick;

            var lblDiscount = new Label { Text = "Discount (Rs):", Location = new Point(10, 420), AutoSize = true, Font = new Font("Segoe UI", 9) };
            txtDiscount = new TextBox { Location = new Point(120, 418), Size = new Size(100, 24), Font = new Font("Segoe UI", 10), Text = "0" };
            txtDiscount.TextChanged += (s, e) => UpdateTotals();

            var lblPayment = new Label { Text = "Payment:", Location = new Point(10, 452), AutoSize = true, Font = new Font("Segoe UI", 9) };
            cboPayment = new ComboBox { Location = new Point(80, 450), Size = new Size(140, 26), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 9) };
            cboPayment.Items.AddRange(new object[] { "Cash", "Card", "Bank Transfer" });
            cboPayment.SelectedIndex = 0;

            var lblNotes = new Label { Text = "Notes:", Location = new Point(10, 485), AutoSize = true, Font = new Font("Segoe UI", 9) };
            txtNotes = new TextBox { Location = new Point(10, 503), Size = new Size(555, 40), Multiline = true, Font = new Font("Segoe UI", 9), BorderStyle = BorderStyle.FixedSingle, ScrollBars = ScrollBars.Vertical };

            lblTotal = new Label { Text = "Total:  Rs 0.00",  Location = new Point(10, 555), AutoSize = true, Font = new Font("Segoe UI", 11) };
            lblNet   = new Label { Text = "Net:    Rs 0.00",  Location = new Point(10, 578), AutoSize = true, Font = new Font("Segoe UI", 13, FontStyle.Bold), ForeColor = Color.FromArgb(0,120,215) };

            btnCheckout = new Button
            {
                Text = "✔ CHECKOUT", Location = new Point(280, 555), Size = new Size(150, 50),
                BackColor = Color.FromArgb(0, 120, 215), ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 12, FontStyle.Bold), Cursor = Cursors.Hand
            };
            btnCheckout.Click += BtnCheckout_Click;

            btnClear = new Button
            {
                Text = "Clear", Location = new Point(440, 555), Size = new Size(120, 50),
                BackColor = Color.LightGray, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10)
            };
            btnClear.Click += (s, e) => ClearCart();

            pnlRight.Controls.AddRange(new Control[] {
                lblCartTitle, lblCustomer, cboCustomer, btnNewCustomer, chkHasPrescription,
                dgvCart, lblDiscount, txtDiscount, lblPayment, cboPayment,
                lblNotes, txtNotes, lblTotal, lblNet, btnCheckout, btnClear
            });
            this.Controls.Add(pnlRight);
        }

        private void LoadMedicines(string search = "")
        {
            dgvMedicines.Rows.Clear();
            var list = string.IsNullOrWhiteSpace(search) ? _medDAL.GetAll() : _medDAL.Search(search);
            foreach (var m in list)
                dgvMedicines.Rows.Add(m.MedicineID, m.MedicineName, m.GenericName,
                    $"Rs {m.SalePrice:N2}", m.StockQuantity, m.UnitOfMeasure);
        }

        private void LoadCustomers()
        {
            var custs = _custDAL.GetAll();
            custs.Insert(0, new Customer { CustomerID = 0, FullName = "Walk-in Customer" });
            cboCustomer.DataSource    = custs;
            cboCustomer.DisplayMember = "FullName";
            cboCustomer.ValueMember   = "CustomerID";
        }

        private void BtnAddItem_Click(object sender, EventArgs e)
        {
            if (dgvMedicines.CurrentRow == null) { MessageBox.Show("Please select a medicine."); return; }

            int     medID = Convert.ToInt32(dgvMedicines.CurrentRow.Cells["MedID"].Value);
            string  name  = dgvMedicines.CurrentRow.Cells["Name"].Value.ToString();
            decimal price = decimal.Parse(dgvMedicines.CurrentRow.Cells["Price"].Value.ToString().Replace("Rs ", "").Replace(",", ""));
            int     stock = Convert.ToInt32(dgvMedicines.CurrentRow.Cells["Stock"].Value);
            int     qty   = (int)nudQty.Value;

            if (qty > stock) { MessageBox.Show($"Only {stock} units in stock.", "Stock Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

            // If already in cart, increment
            var existing = _cartItems.Find(i => i.MedicineID == medID);
            if (existing != null)
            {
                existing.Quantity += qty;
                existing.SubTotal  = existing.UnitPrice * existing.Quantity;
            }
            else
            {
                _cartItems.Add(new SaleItem { MedicineID = medID, MedicineName = name, Quantity = qty, UnitPrice = price, SubTotal = price * qty });
            }
            RefreshCart();
        }

        private void RefreshCart()
        {
            dgvCart.Rows.Clear();
            foreach (var item in _cartItems)
                dgvCart.Rows.Add(item.MedicineID, item.MedicineName, item.Quantity,
                    $"Rs {item.UnitPrice:N2}", $"Rs {item.SubTotal:N2}", "✕");
            UpdateTotals();
        }

        private void UpdateTotals()
        {
            decimal total = 0;
            foreach (var item in _cartItems) total += item.SubTotal;
            decimal.TryParse(txtDiscount.Text, out decimal disc);
            decimal net = total - disc;
            lblTotal.Text = $"Total:  Rs {total:N2}";
            lblNet.Text   = $"Net:    Rs {net:N2}";
        }

        private void DgvCart_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex != dgvCart.Columns.Count - 1) return;
            int medID = Convert.ToInt32(dgvCart.Rows[e.RowIndex].Cells["CartMedID"].Value);
            _cartItems.RemoveAll(i => i.MedicineID == medID);
            RefreshCart();
        }

        private void BtnCheckout_Click(object sender, EventArgs e)
        {
            if (_cartItems.Count == 0) { MessageBox.Show("Cart is empty."); return; }
            decimal.TryParse(txtDiscount.Text, out decimal disc);

            var sale = new Sale
            {
                CustomerID    = (int)cboCustomer.SelectedValue == 0 ? (int?)null : (int)cboCustomer.SelectedValue,
                PaymentMethod = cboPayment.Text,
                DiscountAmount = disc,
                Notes         = txtNotes.Text.Trim(),
                Items         = new List<SaleItem>(_cartItems)
            };

            try
            {
                int saleID = _saleService.ProcessSale(sale);
                MessageBox.Show($"Sale #{saleID} completed!\nNet Amount: Rs {sale.NetAmount:N2}",
                    "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearCart();
                LoadMedicines(); // refresh stock
            }
            catch (Exception ex)
            {
                Logger.LogError("SalesForm", "Checkout", ex);
                MessageBox.Show("Error: " + ex.Message, "Sale Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearCart()
        {
            _cartItems.Clear();
            dgvCart.Rows.Clear();
            txtDiscount.Text = "0";
            txtNotes.Clear();
            cboCustomer.SelectedIndex = 0;
            UpdateTotals();
        }
    }
}
