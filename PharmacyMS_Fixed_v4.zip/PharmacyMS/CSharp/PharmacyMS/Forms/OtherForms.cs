using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data;
using PharmacyMS.DAL;
using PharmacyMS.Models;
using PharmacyMS.Utils;

namespace PharmacyMS.Forms
{
    // ══════════════════════════════════════════════════════════════════════════
    //  CustomerForm
    // ══════════════════════════════════════════════════════════════════════════
    public class CustomerForm : Form
    {
        private MenuStrip menuStrip;
        private TextBox txtSearch, txtName, txtPhone, txtEmail, txtAddress, txtNotes;
        private ComboBox cboGender;
        private DateTimePicker dtpDOB;
        private CheckBox chkHasDOB;
        private DataGridView dgv;
        private Button btnAdd, btnSave, btnCancel, btnSearch;
        private Panel pnlDetail;
        private Label lblError, lblTitle;
        private readonly CustomerDAL _dal = new CustomerDAL();
        private Customer _editing = null;

        public CustomerForm()
        {
            this.Text = "Customer Management"; this.Size = new Size(1100, 680); this.BackColor = Color.FromArgb(245,247,250); this.StartPosition = FormStartPosition.CenterScreen;
            menuStrip = new MenuStrip(); var fm = new ToolStripMenuItem("File"); fm.DropDownItems.Add("Close", null, (s,e) => Close()); menuStrip.Items.Add(fm); this.MainMenuStrip = menuStrip; Controls.Add(menuStrip);

            txtSearch = new TextBox { Location=new Point(10,40), Size=new Size(240,26), Font=new Font("Segoe UI",10) };
            btnSearch = new Button  { Text="Search", Location=new Point(260,38), Size=new Size(80,28), BackColor=Color.FromArgb(0,120,215), ForeColor=Color.White, FlatStyle=FlatStyle.Flat };
            btnAdd    = new Button  { Text="+ Add",  Location=new Point(350,38), Size=new Size(80,28), BackColor=Color.FromArgb(0,163,136), ForeColor=Color.White, FlatStyle=FlatStyle.Flat };
            btnSearch.Click += (s,e) => LoadGrid(txtSearch.Text);
            btnAdd.Click    += (s,e) => ShowDetail(null);
            Controls.AddRange(new Control[]{txtSearch,btnSearch,btnAdd});

            dgv = new DataGridView { Location=new Point(10,75), Size=new Size(760,570), ReadOnly=true, AllowUserToAddRows=false, MultiSelect=false, SelectionMode=DataGridViewSelectionMode.FullRowSelect, BackgroundColor=Color.White, RowHeadersVisible=false, Font=new Font("Segoe UI",9), AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill };
            dgv.Columns.Add("CID","ID"); dgv.Columns.Add("CName","Name"); dgv.Columns.Add("CPhone","Phone"); dgv.Columns.Add("CEmail","Email"); dgv.Columns.Add("CGender","Gender");
            var ce = new DataGridViewButtonColumn{HeaderText="Edit",Text="Edit",UseColumnTextForButtonValue=true,Width=60}; dgv.Columns.Add(ce);
            dgv.Columns["CID"].Visible = false;
            dgv.CellClick += (s,e) => { if(e.RowIndex<0||e.ColumnIndex!=dgv.Columns.Count-1) return; int id=Convert.ToInt32(dgv.Rows[e.RowIndex].Cells["CID"].Value); var custs=_dal.Search(""); ShowDetail(custs.Find(c=>c.CustomerID==id)); };
            Controls.Add(dgv);

            pnlDetail = new Panel { Location=new Point(780,35), Size=new Size(310,610), BackColor=Color.White, BorderStyle=BorderStyle.FixedSingle, Visible=false };
            int y=10;
            lblTitle = new Label{Text="Add Customer",Location=new Point(10,y),AutoSize=true,Font=new Font("Segoe UI",12,FontStyle.Bold)}; pnlDetail.Controls.Add(lblTitle); y+=35;
            void AddRow(string lbl, Control ctrl) { pnlDetail.Controls.Add(new Label{Text=lbl,Location=new Point(10,y),AutoSize=true,Font=new Font("Segoe UI",9)}); y+=20; ctrl.Location=new Point(10,y); ctrl.Size=new Size(285,26); pnlDetail.Controls.Add(ctrl); y+=35; }
            txtName    = new TextBox{Font=new Font("Segoe UI",10)}; AddRow("Full Name *", txtName);
            txtPhone   = new TextBox{Font=new Font("Segoe UI",10)}; AddRow("Phone",       txtPhone);
            txtEmail   = new TextBox{Font=new Font("Segoe UI",10)}; AddRow("Email",       txtEmail);
            cboGender  = new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList,Font=new Font("Segoe UI",10)}; cboGender.Items.AddRange(new object[]{"","Male","Female","Other"}); AddRow("Gender", cboGender);
            chkHasDOB  = new CheckBox{Text="Date of Birth",Location=new Point(10,y),AutoSize=true}; pnlDetail.Controls.Add(chkHasDOB); y+=22;
            dtpDOB     = new DateTimePicker{Location=new Point(10,y),Size=new Size(285,26),Format=DateTimePickerFormat.Short}; pnlDetail.Controls.Add(dtpDOB); y+=35;
            txtAddress = new TextBox{Font=new Font("Segoe UI",10),Multiline=true,Size=new Size(285,50),Location=new Point(10,y),ScrollBars=ScrollBars.Vertical}; pnlDetail.Controls.Add(new Label{Text="Address",Location=new Point(10,y-18),AutoSize=true}); pnlDetail.Controls.Add(txtAddress); y+=70;
            txtNotes   = new TextBox{Font=new Font("Segoe UI",9),Multiline=true,Size=new Size(285,40),Location=new Point(10,y),ScrollBars=ScrollBars.Vertical}; pnlDetail.Controls.Add(new Label{Text="Medical Notes",Location=new Point(10,y-18),AutoSize=true}); pnlDetail.Controls.Add(txtNotes); y+=60;
            lblError = new Label{Location=new Point(10,y),Size=new Size(285,18),ForeColor=Color.Red,Font=new Font("Segoe UI",8)}; pnlDetail.Controls.Add(lblError); y+=22;
            btnSave   = new Button{Text="Save",  Location=new Point(10,y),Size=new Size(130,32),BackColor=Color.FromArgb(0,120,215),ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",10,FontStyle.Bold)};
            btnCancel = new Button{Text="Cancel",Location=new Point(155,y),Size=new Size(130,32),BackColor=Color.LightGray,FlatStyle=FlatStyle.Flat};
            btnSave.Click   += BtnSave_Click;
            btnCancel.Click += (s,e)=>pnlDetail.Visible=false;
            pnlDetail.Controls.AddRange(new Control[]{btnSave,btnCancel});
            Controls.Add(pnlDetail);
            LoadGrid();
        }

        private void LoadGrid(string search="")
        {
            dgv.Rows.Clear();
            var list = string.IsNullOrWhiteSpace(search) ? _dal.GetAll() : _dal.Search(search);
            foreach (var c in list) dgv.Rows.Add(c.CustomerID, c.FullName, c.Phone, c.Email, c.Gender, "Edit");
        }

        private void ShowDetail(Customer c)
        {
            _editing = c; lblTitle.Text = c==null?"Add Customer":"Edit Customer"; lblError.Text="";
            txtName.Text=c?.FullName??""; txtPhone.Text=c?.Phone??""; txtEmail.Text=c?.Email??"";
            txtAddress.Text=c?.Address??""; txtNotes.Text=c?.MedicalNotes??"";
            cboGender.Text=c?.Gender??"";
            chkHasDOB.Checked=c?.DateOfBirth.HasValue??false;
            if(c?.DateOfBirth.HasValue==true) dtpDOB.Value=c.DateOfBirth.Value;
            pnlDetail.Visible=true; txtName.Focus();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            lblError.Text="";
            if(!Validator.IsNotEmpty(txtName.Text)){lblError.Text="Name required.";return;}
            var c = _editing??new Customer();
            c.FullName=txtName.Text.Trim(); c.Phone=txtPhone.Text.Trim(); c.Email=txtEmail.Text.Trim();
            c.Address=txtAddress.Text.Trim(); c.Gender=cboGender.Text; c.MedicalNotes=txtNotes.Text.Trim();
            c.DateOfBirth=chkHasDOB.Checked?dtpDOB.Value:(DateTime?)null;
            try { if(_editing==null) _dal.Insert(c); else _dal.Update(c); pnlDetail.Visible=false; LoadGrid(); }
            catch(Exception ex){Logger.LogError("CustomerForm","Save",ex);lblError.Text="Error: "+ex.Message;}
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SupplierForm
    // ══════════════════════════════════════════════════════════════════════════
    public class SupplierForm : Form
    {
        private MenuStrip menuStrip;
        private DataGridView dgv;
        private Panel pnlDetail;
        private TextBox txtName,txtContact,txtEmail,txtPhone,txtAddress,txtCity;
        private CheckBox chkActive;
        private Button btnAdd,btnSave,btnCancel;
        private Label lblError,lblTitle;
        private readonly SupplierDAL _dal = new SupplierDAL();
        private Supplier _editing = null;

        public SupplierForm()
        {
            this.Text="Supplier Management"; this.Size=new Size(1100,680); this.BackColor=Color.FromArgb(245,247,250); this.StartPosition=FormStartPosition.CenterScreen;
            menuStrip=new MenuStrip(); var fm=new ToolStripMenuItem("File"); fm.DropDownItems.Add("Close",null,(s,e)=>Close()); menuStrip.Items.Add(fm); this.MainMenuStrip=menuStrip; Controls.Add(menuStrip);
            btnAdd=new Button{Text="+ Add Supplier",Location=new Point(10,38),Size=new Size(140,28),BackColor=Color.FromArgb(0,163,136),ForeColor=Color.White,FlatStyle=FlatStyle.Flat}; btnAdd.Click+=(s,e)=>ShowDetail(null); Controls.Add(btnAdd);
            dgv=new DataGridView{Location=new Point(10,75),Size=new Size(760,570),ReadOnly=true,AllowUserToAddRows=false,MultiSelect=false,SelectionMode=DataGridViewSelectionMode.FullRowSelect,BackgroundColor=Color.White,RowHeadersVisible=false,Font=new Font("Segoe UI",9),AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill};
            dgv.Columns.Add("SID","ID"); dgv.Columns.Add("SName","Supplier"); dgv.Columns.Add("SPhone","Phone"); dgv.Columns.Add("SCity","City"); dgv.Columns.Add("SActive","Active");
            var ce=new DataGridViewButtonColumn{HeaderText="Edit",Text="Edit",UseColumnTextForButtonValue=true,Width=60}; dgv.Columns.Add(ce); dgv.Columns["SID"].Visible=false;
            dgv.CellClick+=(s,e)=>{ if(e.RowIndex<0||e.ColumnIndex!=dgv.Columns.Count-1) return; int id=Convert.ToInt32(dgv.Rows[e.RowIndex].Cells["SID"].Value); var all=_dal.GetAll(false); ShowDetail(all.Find(x=>x.SupplierID==id)); }; Controls.Add(dgv);

            pnlDetail=new Panel{Location=new Point(780,35),Size=new Size(310,580),BackColor=Color.White,BorderStyle=BorderStyle.FixedSingle,Visible=false};
            int y=10; lblTitle=new Label{Text="Add Supplier",Location=new Point(10,y),AutoSize=true,Font=new Font("Segoe UI",12,FontStyle.Bold)}; pnlDetail.Controls.Add(lblTitle); y+=35;
            void AR(string l,TextBox t){pnlDetail.Controls.Add(new Label{Text=l,Location=new Point(10,y),AutoSize=true,Font=new Font("Segoe UI",9)});y+=20;t.Location=new Point(10,y);t.Size=new Size(285,26);t.Font=new Font("Segoe UI",10);pnlDetail.Controls.Add(t);y+=35;}
            txtName=new TextBox(); AR("Supplier Name *",txtName); txtContact=new TextBox(); AR("Contact Name",txtContact); txtPhone=new TextBox(); AR("Phone *",txtPhone); txtEmail=new TextBox(); AR("Email",txtEmail); txtCity=new TextBox(); AR("City",txtCity); txtAddress=new TextBox{Multiline=true}; AR("Address",txtAddress);
            chkActive=new CheckBox{Text="Active",Location=new Point(10,y),AutoSize=true,Checked=true}; pnlDetail.Controls.Add(chkActive); y+=30;
            lblError=new Label{Location=new Point(10,y),Size=new Size(285,18),ForeColor=Color.Red,Font=new Font("Segoe UI",8)}; pnlDetail.Controls.Add(lblError); y+=22;
            btnSave=new Button{Text="Save",Location=new Point(10,y),Size=new Size(130,32),BackColor=Color.FromArgb(0,120,215),ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",10,FontStyle.Bold)};
            btnCancel=new Button{Text="Cancel",Location=new Point(155,y),Size=new Size(130,32),BackColor=Color.LightGray,FlatStyle=FlatStyle.Flat};
            btnSave.Click+=(s,e)=>Save(); btnCancel.Click+=(s,e)=>pnlDetail.Visible=false;
            pnlDetail.Controls.AddRange(new Control[]{btnSave,btnCancel}); Controls.Add(pnlDetail); LoadGrid();
        }
        private void LoadGrid(){dgv.Rows.Clear();foreach(var s in _dal.GetAll(false)) dgv.Rows.Add(s.SupplierID,s.SupplierName,s.Phone,s.City,s.IsActive?"Yes":"No","Edit");}
        private void ShowDetail(Supplier s){_editing=s;lblTitle.Text=s==null?"Add Supplier":"Edit Supplier";lblError.Text="";txtName.Text=s?.SupplierName??"";txtContact.Text=s?.ContactName??"";txtPhone.Text=s?.Phone??"";txtEmail.Text=s?.Email??"";txtCity.Text=s?.City??"";txtAddress.Text=s?.Address??"";chkActive.Checked=s?.IsActive??true;pnlDetail.Visible=true;txtName.Focus();}
        private void Save(){lblError.Text="";if(!Validator.IsNotEmpty(txtName.Text)||!Validator.IsNotEmpty(txtPhone.Text)){lblError.Text="Name and Phone required.";return;}var s=_editing??new Supplier();s.SupplierName=txtName.Text.Trim();s.ContactName=txtContact.Text.Trim();s.Phone=txtPhone.Text.Trim();s.Email=txtEmail.Text.Trim();s.City=txtCity.Text.Trim();s.Address=txtAddress.Text.Trim();s.IsActive=chkActive.Checked;try{if(_editing==null)_dal.Insert(s);else _dal.Update(s);pnlDetail.Visible=false;LoadGrid();}catch(Exception ex){Logger.LogError("SupplierForm","Save",ex);lblError.Text="Error: "+ex.Message;}}
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  UserForm
    // ══════════════════════════════════════════════════════════════════════════
    public class UserForm : Form
    {
        private MenuStrip menuStrip;
        private DataGridView dgv;
        private Panel pnlDetail;
        private TextBox txtUsername,txtFullName,txtEmail,txtPhone,txtPassword;
        private ComboBox cboRole;
        private CheckBox chkActive;
        private Button btnAdd,btnSave,btnCancel;
        private Label lblError,lblTitle;
        private readonly UserDAL _dal = new UserDAL();
        private User _editing = null;

        public UserForm()
        {
            this.Text="User Management"; this.Size=new Size(1100,680); this.BackColor=Color.FromArgb(245,247,250); this.StartPosition=FormStartPosition.CenterScreen;
            menuStrip=new MenuStrip(); var fm=new ToolStripMenuItem("File"); fm.DropDownItems.Add("Close",null,(s,e)=>Close()); menuStrip.Items.Add(fm); this.MainMenuStrip=menuStrip; Controls.Add(menuStrip);
            btnAdd=new Button{Text="+ Add User",Location=new Point(10,38),Size=new Size(120,28),BackColor=Color.FromArgb(0,163,136),ForeColor=Color.White,FlatStyle=FlatStyle.Flat}; btnAdd.Click+=(s,e)=>ShowDetail(null); Controls.Add(btnAdd);
            dgv=new DataGridView{Location=new Point(10,75),Size=new Size(760,570),ReadOnly=true,AllowUserToAddRows=false,MultiSelect=false,SelectionMode=DataGridViewSelectionMode.FullRowSelect,BackgroundColor=Color.White,RowHeadersVisible=false,Font=new Font("Segoe UI",9),AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill};
            dgv.Columns.Add("UID","ID"); dgv.Columns.Add("UName","Username"); dgv.Columns.Add("UFull","Full Name"); dgv.Columns.Add("URole","Role"); dgv.Columns.Add("UActive","Active");
            var ce=new DataGridViewButtonColumn{HeaderText="Edit",Text="Edit",UseColumnTextForButtonValue=true,Width=60}; dgv.Columns.Add(ce); dgv.Columns["UID"].Visible=false;
            dgv.CellClick+=(s,e)=>{ if(e.RowIndex<0||e.ColumnIndex!=dgv.Columns.Count-1) return; int id=Convert.ToInt32(dgv.Rows[e.RowIndex].Cells["UID"].Value); var all=_dal.GetAll(); ShowDetail(all.Find(x=>x.UserID==id)); }; Controls.Add(dgv);

            pnlDetail=new Panel{Location=new Point(780,35),Size=new Size(310,580),BackColor=Color.White,BorderStyle=BorderStyle.FixedSingle,Visible=false};
            int y=10; lblTitle=new Label{Text="Add User",Location=new Point(10,y),AutoSize=true,Font=new Font("Segoe UI",12,FontStyle.Bold)}; pnlDetail.Controls.Add(lblTitle); y+=35;
            void AR(string l,Control t,bool multiline=false){pnlDetail.Controls.Add(new Label{Text=l,Location=new Point(10,y),AutoSize=true,Font=new Font("Segoe UI",9)});y+=20;t.Location=new Point(10,y);t.Size=new Size(285,multiline?50:26);pnlDetail.Controls.Add(t);y+=multiline?60:35;}
            txtUsername=new TextBox{Font=new Font("Segoe UI",10)}; AR("Username *",txtUsername);
            txtFullName=new TextBox{Font=new Font("Segoe UI",10)}; AR("Full Name *",txtFullName);
            txtEmail=new TextBox{Font=new Font("Segoe UI",10)};    AR("Email *",txtEmail);
            txtPhone=new TextBox{Font=new Font("Segoe UI",10)};    AR("Phone",txtPhone);
            txtPassword=new TextBox{Font=new Font("Segoe UI",10),PasswordChar='●'}; AR("Password (leave blank to keep)",txtPassword);
            cboRole=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList,Font=new Font("Segoe UI",10)}; AR("Role *",cboRole);
            chkActive=new CheckBox{Text="Active",Location=new Point(10,y),AutoSize=true,Checked=true}; pnlDetail.Controls.Add(chkActive); y+=30;
            lblError=new Label{Location=new Point(10,y),Size=new Size(285,18),ForeColor=Color.Red,Font=new Font("Segoe UI",8)}; pnlDetail.Controls.Add(lblError); y+=22;
            btnSave=new Button{Text="Save",Location=new Point(10,y),Size=new Size(130,32),BackColor=Color.FromArgb(0,120,215),ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",10,FontStyle.Bold)};
            btnCancel=new Button{Text="Cancel",Location=new Point(155,y),Size=new Size(130,32),BackColor=Color.LightGray,FlatStyle=FlatStyle.Flat};
            btnSave.Click+=(s,e)=>Save(); btnCancel.Click+=(s,e)=>pnlDetail.Visible=false;
            pnlDetail.Controls.AddRange(new Control[]{btnSave,btnCancel}); Controls.Add(pnlDetail);
            var roles=_dal.GetRoles(); cboRole.DataSource=roles; cboRole.DisplayMember="RoleName"; cboRole.ValueMember="RoleID";
            LoadGrid();
        }
        private void LoadGrid(){dgv.Rows.Clear();foreach(var u in _dal.GetAll()) dgv.Rows.Add(u.UserID,u.Username,u.FullName,u.RoleName,u.IsActive?"Yes":"No","Edit");}
        private void ShowDetail(User u){_editing=u;lblTitle.Text=u==null?"Add User":"Edit User";lblError.Text="";txtUsername.Text=u?.Username??"";txtFullName.Text=u?.FullName??"";txtEmail.Text=u?.Email??"";txtPhone.Text=u?.Phone??"";txtPassword.Text="";if(u!=null&&cboRole!=null)cboRole.SelectedValue=u.RoleID;chkActive.Checked=u?.IsActive??true;txtUsername.Enabled=u==null;pnlDetail.Visible=true;txtFullName.Focus();}
        private void Save(){lblError.Text="";if(!Validator.IsNotEmpty(txtFullName.Text)||!Validator.IsValidEmail(txtEmail.Text)){lblError.Text="Full name and valid email required.";return;}if(_editing==null&&!Validator.IsStrongPassword(txtPassword.Text)){lblError.Text="Password: min 6 chars, 1 uppercase, 1 digit.";return;}var u=_editing??new User();u.FullName=txtFullName.Text.Trim();u.Email=txtEmail.Text.Trim();u.Phone=txtPhone.Text.Trim();u.RoleID=(int)cboRole.SelectedValue;u.IsActive=chkActive.Checked;try{if(_editing==null){u.Username=txtUsername.Text.Trim();u.PasswordHash=PasswordHelper.Hash(txtPassword.Text);_dal.Insert(u);}else{_dal.Update(u);if(!string.IsNullOrWhiteSpace(txtPassword.Text))_dal.ChangePassword(u.UserID,PasswordHelper.Hash(txtPassword.Text));}pnlDetail.Visible=false;LoadGrid();}catch(Exception ex){Logger.LogError("UserForm","Save",ex);lblError.Text="Error: "+ex.Message;}}
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  PurchaseOrderForm
    // ══════════════════════════════════════════════════════════════════════════
    public class PurchaseOrderForm : Form
    {
        private MenuStrip menuStrip;
        private DataGridView dgvOrders;
        private Button btnNew, btnRefresh;
        private readonly PurchaseOrderDAL _dal = new PurchaseOrderDAL();

        public PurchaseOrderForm()
        {
            this.Text="Purchase Orders"; this.Size=new Size(1100,680); this.BackColor=Color.FromArgb(245,247,250); this.StartPosition=FormStartPosition.CenterScreen;
            menuStrip=new MenuStrip(); var fm=new ToolStripMenuItem("File"); fm.DropDownItems.Add("Close",null,(s,e)=>Close()); menuStrip.Items.Add(fm); this.MainMenuStrip=menuStrip; Controls.Add(menuStrip);
            btnNew    =new Button{Text="+ New Order",Location=new Point(10,38),Size=new Size(120,28),BackColor=Color.FromArgb(0,163,136),ForeColor=Color.White,FlatStyle=FlatStyle.Flat}; btnNew.Click+=(s,e)=>MessageBox.Show("New PO form — extend this to add full order entry with items.","Info");
            btnRefresh=new Button{Text="↻ Refresh",Location=new Point(140,38),Size=new Size(100,28),FlatStyle=FlatStyle.Flat}; btnRefresh.Click+=(s,e)=>LoadGrid();
            Controls.AddRange(new Control[]{btnNew,btnRefresh});
            dgvOrders=new DataGridView{Location=new Point(10,75),Size=new Size(1060,560),ReadOnly=true,AllowUserToAddRows=false,BackgroundColor=Color.White,RowHeadersVisible=false,Font=new Font("Segoe UI",9),AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,SelectionMode=DataGridViewSelectionMode.FullRowSelect};
            Controls.Add(dgvOrders); LoadGrid();
        }
        private void LoadGrid(){try{dgvOrders.DataSource=_dal.GetAll();}catch(Exception ex){Logger.LogError("PurchaseOrderForm","LoadGrid",ex);MessageBox.Show("Error loading orders.");}}
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  ReportForm
    // ══════════════════════════════════════════════════════════════════════════
    public class ReportForm : Form
    {
        private MenuStrip menuStrip;
        private ComboBox cboReportType;
        private DateTimePicker dtpFrom, dtpTo;
        private Button btnGenerate;
        private DataGridView dgvReport;
        private Label lblTitle;
        private readonly SaleDAL _saleDAL = new SaleDAL();
        private readonly MedicineDAL _medDAL = new MedicineDAL();

        public ReportForm()
        {
            this.Text="Reports"; this.Size=new Size(1100,700); this.BackColor=Color.FromArgb(245,247,250); this.StartPosition=FormStartPosition.CenterScreen;
            menuStrip=new MenuStrip(); var fm=new ToolStripMenuItem("File"); fm.DropDownItems.Add("Close",null,(s,e)=>Close()); menuStrip.Items.Add(fm); this.MainMenuStrip=menuStrip; Controls.Add(menuStrip);
            Controls.Add(new Label{Text="Report Type:",Location=new Point(10,42),AutoSize=true,Font=new Font("Segoe UI",10)});
            cboReportType=new ComboBox{Location=new Point(110,40),Size=new Size(220,26),DropDownStyle=ComboBoxStyle.DropDownList,Font=new Font("Segoe UI",10)};
            cboReportType.Items.AddRange(new object[]{"Sales by Date Range","Daily Sales Summary","Low Stock Report","Medicine Sales Performance","Expiring Medicines","Customer Purchase History","Purchase Order Overview"});
            cboReportType.SelectedIndex=0; Controls.Add(cboReportType);
            Controls.Add(new Label{Text="From:",Location=new Point(345,42),AutoSize=true,Font=new Font("Segoe UI",10)});
            dtpFrom=new DateTimePicker{Location=new Point(390,40),Size=new Size(140,26),Format=DateTimePickerFormat.Short,Value=DateTime.Today.AddMonths(-1)}; Controls.Add(dtpFrom);
            Controls.Add(new Label{Text="To:",Location=new Point(542,42),AutoSize=true,Font=new Font("Segoe UI",10)});
            dtpTo=new DateTimePicker{Location=new Point(565,40),Size=new Size(140,26),Format=DateTimePickerFormat.Short,Value=DateTime.Today}; Controls.Add(dtpTo);
            btnGenerate=new Button{Text="Generate",Location=new Point(718,38),Size=new Size(100,28),BackColor=Color.FromArgb(0,120,215),ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",10,FontStyle.Bold)}; btnGenerate.Click+=BtnGenerate_Click; Controls.Add(btnGenerate);
            lblTitle=new Label{Text="",Location=new Point(10,78),AutoSize=true,Font=new Font("Segoe UI",11,FontStyle.Bold)}; Controls.Add(lblTitle);
            dgvReport=new DataGridView{Location=new Point(10,105),Size=new Size(1060,550),ReadOnly=true,AllowUserToAddRows=false,BackgroundColor=Color.White,RowHeadersVisible=false,Font=new Font("Segoe UI",9),AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill}; Controls.Add(dgvReport);
        }

        private void BtnGenerate_Click(object sender, EventArgs e)
        {
            lblTitle.Text=cboReportType.Text;
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var ada = new MySql.Data.MySqlClient.MySqlDataAdapter("", conn))
                {
                    var dt = new DataTable();
                    switch (cboReportType.SelectedIndex)
                    {
                        case 0: dgvReport.DataSource=_saleDAL.GetByDateRange(dtpFrom.Value,dtpTo.Value); return;
                        case 1: ada.SelectCommand.CommandText="SELECT * FROM vw_DailySalesSummary WHERE SaleDay BETWEEN @f AND @t"; break;
                        case 2: dgvReport.DataSource=_medDAL.GetLowStock(); return;
                        case 3: ada.SelectCommand.CommandText="SELECT * FROM vw_MedicineSalesPerformance ORDER BY TotalRevenue DESC"; break;
                        case 4: ada.SelectCommand.CommandText="SELECT * FROM vw_ExpiringMedicines"; break;
                        case 5: ada.SelectCommand.CommandText="SELECT * FROM vw_CustomerPurchaseHistory ORDER BY SaleDate DESC LIMIT 500"; break;
                        case 6: ada.SelectCommand.CommandText="SELECT * FROM vw_PurchaseOrderOverview ORDER BY OrderDate DESC"; break;
                    }
                    if(cboReportType.SelectedIndex==1){ada.SelectCommand.Parameters.AddWithValue("@f",dtpFrom.Value.Date);ada.SelectCommand.Parameters.AddWithValue("@t",dtpTo.Value.Date);}
                    ada.Fill(dt); dgvReport.DataSource=dt;
                }
            }
            catch(Exception ex){Logger.LogError("ReportForm","Generate",ex);MessageBox.Show("Error: "+ex.Message);}
        }
    }
}
