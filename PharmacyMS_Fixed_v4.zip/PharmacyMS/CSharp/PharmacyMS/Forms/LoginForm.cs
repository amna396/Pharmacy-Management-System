using System;
using System.Drawing;
using System.Windows.Forms;
using PharmacyMS.Services;
using PharmacyMS.Utils;

namespace PharmacyMS.Forms
{
    public class LoginForm : Form
    {
        // ── Controls ──────────────────────────────────────────────────────────
        private Panel   pnlMain;
        private Label   lblTitle, lblSubtitle, lblUsername, lblPassword, lblError;
        private TextBox txtUsername, txtPassword;
        private Button  btnLogin, btnExit;
        private CheckBox chkShowPassword;
        private MenuStrip menuStrip;

        private readonly AuthService _auth = new AuthService();

        public LoginForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            // ── Form ──────────────────────────────────────────────────────────
            this.Text            = "CureWell Pharmacy – Login";
            this.Size            = new Size(480, 560);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;
            this.BackColor       = Color.WhiteSmoke;

            // ── File Menu ─────────────────────────────────────────────────────
            menuStrip = new MenuStrip();
            var fileMenu = new ToolStripMenuItem("File");
            fileMenu.DropDownItems.Add("Exit", null, (s, e) => Application.Exit());
            menuStrip.Items.Add(fileMenu);
            this.MainMenuStrip = menuStrip;
            this.Controls.Add(menuStrip);

            // ── Panel ─────────────────────────────────────────────────────────
            pnlMain = new Panel
            {
                Size      = new Size(380, 420),
                Location  = new Point(50, 60),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };
            this.Controls.Add(pnlMain);

            // ── Title ─────────────────────────────────────────────────────────
            lblTitle = new Label
            {
                Text      = "CureWell Pharmacy",
                Font      = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 120, 215),
                Location  = new Point(40, 30),
                Size      = new Size(300, 35),
                TextAlign = ContentAlignment.MiddleCenter
            };
            pnlMain.Controls.Add(lblTitle);

            lblSubtitle = new Label
            {
                Text      = "Management System",
                Font      = new Font("Segoe UI", 11),
                ForeColor = Color.Gray,
                Location  = new Point(80, 65),
                Size      = new Size(220, 25),
                TextAlign = ContentAlignment.MiddleCenter
            };
            pnlMain.Controls.Add(lblSubtitle);

            // ── Username ──────────────────────────────────────────────────────
            lblUsername = new Label { Text = "Username:", Location = new Point(50, 120), Size = new Size(100, 20), Font = new Font("Segoe UI", 10) };
            txtUsername = new TextBox { Location = new Point(50, 142), Size = new Size(280, 28), Font = new Font("Segoe UI", 11), BorderStyle = BorderStyle.FixedSingle };
            pnlMain.Controls.AddRange(new Control[] { lblUsername, txtUsername });

            // ── Password ──────────────────────────────────────────────────────
            lblPassword = new Label { Text = "Password:", Location = new Point(50, 185), Size = new Size(100, 20), Font = new Font("Segoe UI", 10) };
            txtPassword = new TextBox
            {
                Location     = new Point(50, 207),
                Size         = new Size(280, 28),
                Font         = new Font("Segoe UI", 11),
                BorderStyle  = BorderStyle.FixedSingle,
                PasswordChar = '●'
            };
            pnlMain.Controls.AddRange(new Control[] { lblPassword, txtPassword });

            // ── Show Password ─────────────────────────────────────────────────
            chkShowPassword = new CheckBox
            {
                Text     = "Show password",
                Location = new Point(50, 242),
                Size     = new Size(150, 20),
                Font     = new Font("Segoe UI", 9)
            };
            chkShowPassword.CheckedChanged += (s, e) =>
                txtPassword.PasswordChar = chkShowPassword.Checked ? '\0' : '●';
            pnlMain.Controls.Add(chkShowPassword);

            // ── Error label ───────────────────────────────────────────────────
            lblError = new Label
            {
                Text      = "",
                ForeColor = Color.Red,
                Location  = new Point(50, 270),
                Size      = new Size(280, 20),
                Font      = new Font("Segoe UI", 9)
            };
            pnlMain.Controls.Add(lblError);

            // ── Login Button ──────────────────────────────────────────────────
            btnLogin = new Button
            {
                Text      = "LOGIN",
                Location  = new Point(50, 300),
                Size      = new Size(280, 42),
                Font      = new Font("Segoe UI", 12, FontStyle.Bold),
                BackColor = Color.FromArgb(0, 120, 215),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor    = Cursors.Hand
            };
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.Click += BtnLogin_Click;
            pnlMain.Controls.Add(btnLogin);

            // ── Exit Button ───────────────────────────────────────────────────
            btnExit = new Button
            {
                Text      = "Exit",
                Location  = new Point(50, 355),
                Size      = new Size(280, 35),
                Font      = new Font("Segoe UI", 10),
                BackColor = Color.LightGray,
                FlatStyle = FlatStyle.Flat,
                Cursor    = Cursors.Hand
            };
            btnExit.Click += (s, e) => Application.Exit();
            pnlMain.Controls.Add(btnExit);

            // ── Enter key ─────────────────────────────────────────────────────
            this.AcceptButton = btnLogin;
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            lblError.Text = "";

            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            // Validate inputs
            if (!Validator.IsNotEmpty(username)) { lblError.Text = "Please enter your username."; txtUsername.Focus(); return; }
            if (!Validator.IsNotEmpty(password)) { lblError.Text = "Please enter your password."; txtPassword.Focus(); return; }

            btnLogin.Enabled = false;
            btnLogin.Text    = "Logging in...";

            try
            {
                var user = _auth.Login(username, password);
                if (user != null)
                {
                    var dashboard = new DashboardForm();
                    this.Hide();
                    dashboard.FormClosed += (s2, e2) => this.Close();
                    dashboard.Show();
                }
                else
                {
                    lblError.Text    = "Invalid username or password.";
                    txtPassword.Clear();
                    txtPassword.Focus();
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("LoginForm", "Login", ex);
                lblError.Text = "An error occurred. Please try again.";
            }
            finally
            {
                btnLogin.Enabled = true;
                btnLogin.Text    = "LOGIN";
            }
        }
    }
}
