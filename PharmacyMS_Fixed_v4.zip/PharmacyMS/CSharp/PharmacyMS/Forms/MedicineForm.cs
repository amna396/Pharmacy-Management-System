using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using PharmacyMS.DAL;
using PharmacyMS.Models;
using PharmacyMS.Utils;

namespace PharmacyMS.Forms
{
    /// <summary>
    /// Add / Edit / Search Medicines — same form for both Add and Edit.
    /// </summary>
    public class MedicineForm : Form
    {
        // ── List side ─────────────────────────────────────────────────────────
        private TextBox   txtSearch;
        private ComboBox  cboFilterCategory;
        private Button    btnSearch, btnAdd, btnRefresh;
        private DataGridView dgvMedicines;

        // ── Detail panel ──────────────────────────────────────────────────────
        private Panel     pnlDetail;
        private Label     lblFormTitle;
        private TextBox   txtName, txtGeneric, txtUnitPrice, txtSalePrice;
        private TextBox   txtStock, txtReorder, txtShelf;
        private ComboBox  cboCategory, cboSupplier, cboUnit;
        private CheckBox  chkPrescription, chkActive;
        private Button    btnSave, btnCancel;
        private Label     lblError;
        private MenuStrip menuStrip;
        private Panel     pnlSearch;

        private readonly MedicineDAL  _medDAL  = new MedicineDAL();
        private readonly CategoryDAL  _catDAL  = new CategoryDAL();
        private readonly SupplierDAL  _supDAL  = new SupplierDAL();
        private Medicine _editing = null;  // null = add mode

        public MedicineForm()
        {
            InitializeComponent();
            LoadCombos();
            LoadGrid();
        }

        private void InitializeComponent()
        {
            this.Text          = "Medicine Management";
            this.Size          = new Size(1200, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor     = Color.FromArgb(245, 247, 250);

            // ── File Menu ─────────────────────────────────────────────────────
            menuStrip = new MenuStrip();
            var fileMenu = new ToolStripMenuItem("File");
            fileMenu.DropDownItems.Add("Add New Medicine", null, (s, e) => ShowDetail(null));
            fileMenu.DropDownItems.Add("Refresh",          null, (s, e) => LoadGrid());
            fileMenu.DropDownItems.Add(new ToolStripSeparator());
            fileMenu.DropDownItems.Add("Close",            null, (s, e) => this.Close());
            menuStrip.Items.Add(fileMenu);
            this.MainMenuStrip = menuStrip;
            this.Controls.Add(menuStrip);

            // ── Search Panel ──────────────────────────────────────────────────
            pnlSearch = new Panel { Location = new Point(10, 35), Size = new Size(780, 50), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };
            txtSearch          = new TextBox   { Location = new Point(10,  12), Size = new Size(220, 26), Font = new Font("Segoe UI", 10) };
            cboFilterCategory  = new ComboBox  { Location = new Point(240, 12), Size = new Size(160, 26), Font = new Font("Segoe UI", 10), DropDownStyle = ComboBoxStyle.DropDownList };
            btnSearch          = new Button    { Text = "Search", Location = new Point(410, 11), Size = new Size(80, 28), BackColor = Color.FromArgb(0,120,215), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            btnAdd             = new Button    { Text = "+ Add",  Location = new Point(500, 11), Size = new Size(80, 28), BackColor = Color.FromArgb(0,163,136), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            btnRefresh         = new Button    { Text = "↻",      Location = new Point(590, 11), Size = new Size(40,  28), FlatStyle = FlatStyle.Flat };

            btnSearch.Click  += (s, e) => LoadGrid(txtSearch.Text, (cboFilterCategory.SelectedItem as Category)?.CategoryID);
            btnAdd.Click     += (s, e) => ShowDetail(null);
            btnRefresh.Click += (s, e) => LoadGrid();
            txtSearch.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) btnSearch.PerformClick(); };

            pnlSearch.Controls.AddRange(new Control[] { txtSearch, cboFilterCategory, btnSearch, btnAdd, btnRefresh });
            this.Controls.Add(pnlSearch);

            // ── DataGridView ──────────────────────────────────────────────────
            dgvMedicines = new DataGridView
            {
                Location          = new Point(10, 95),
                Size              = new Size(780, 560),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode     = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect       = false,
                ReadOnly          = true,
                AllowUserToAddRows = false,
                BackgroundColor   = Color.White,
                BorderStyle       = BorderStyle.None,
                Font              = new Font("Segoe UI", 9),
                RowHeadersVisible = false,
                AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(240, 248, 255) }
            };
            dgvMedicines.Columns.Add("MedicineID",   "ID");
            dgvMedicines.Columns.Add("MedicineName", "Medicine");
            dgvMedicines.Columns.Add("GenericName",  "Generic");
            dgvMedicines.Columns.Add("CategoryName", "Category");
            dgvMedicines.Columns.Add("SalePrice",    "Price");
            dgvMedicines.Columns.Add("StockQuantity","Stock");
            dgvMedicines.Columns.Add("UnitOfMeasure","Unit");

            // Edit / Delete buttons inside grid
            var colEdit = new DataGridViewButtonColumn { HeaderText = "Edit",   Text = "Edit",   UseColumnTextForButtonValue = true, Width = 60 };
            var colDel  = new DataGridViewButtonColumn { HeaderText = "Delete", Text = "Delete", UseColumnTextForButtonValue = true, Width = 60 };
            dgvMedicines.Columns.Add(colEdit);
            dgvMedicines.Columns.Add(colDel);
            dgvMedicines.Columns["MedicineID"].Visible = false;

            dgvMedicines.CellClick += DgvMedicines_CellClick;
            this.Controls.Add(dgvMedicines);

            // ── Detail Panel ──────────────────────────────────────────────────
            pnlDetail = new Panel
            {
                Location    = new Point(800, 35),
                Size        = new Size(380, 620),
                BackColor   = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Visible     = false
            };
            int y = 10;
            lblFormTitle = AddLabel(pnlDetail, "Add Medicine", 10, y, bold: true, size: 13); y += 35;

            AddLabel(pnlDetail, "Medicine Name *", 10, y); y += 22;
            txtName = AddTextBox(pnlDetail, 10, y, 355); y += 35;

            AddLabel(pnlDetail, "Generic Name", 10, y); y += 22;
            txtGeneric = AddTextBox(pnlDetail, 10, y, 355); y += 35;

            AddLabel(pnlDetail, "Category *", 10, y); y += 22;
            cboCategory = AddComboBox(pnlDetail, 10, y, 170); y += 35;

            AddLabel(pnlDetail, "Supplier", 10, y); y += 22;
            cboSupplier = AddComboBox(pnlDetail, 10, y, 355); y += 35;

            AddLabel(pnlDetail, "Unit Price *", 10, y);
            AddLabel(pnlDetail, "Sale Price *", 195, y - 22 + 22); y += 22;
            txtUnitPrice = AddTextBox(pnlDetail, 10,  y, 170);
            txtSalePrice = AddTextBox(pnlDetail, 195, y, 170); y += 35;

            AddLabel(pnlDetail, "Stock Qty", 10, y);
            AddLabel(pnlDetail, "Reorder Level", 195, y); y += 22;
            txtStock   = AddTextBox(pnlDetail, 10,  y, 170);
            txtReorder = AddTextBox(pnlDetail, 195, y, 170); y += 35;

            AddLabel(pnlDetail, "Unit of Measure", 10, y); y += 22;
            cboUnit = AddComboBox(pnlDetail, 10, y, 170);
            cboUnit.Items.AddRange(new object[] { "Tablets","Capsules","Syrup","Cream","Inhaler","Injection","Drops","Sachet","Patch" });
            y += 35;

            AddLabel(pnlDetail, "Shelf Location", 10, y); y += 22;
            txtShelf = AddTextBox(pnlDetail, 10, y, 355); y += 35;

            chkPrescription = new CheckBox { Text = "Requires Prescription", Location = new Point(10, y), AutoSize = true, Font = new Font("Segoe UI", 9) };
            chkActive       = new CheckBox { Text = "Active",                Location = new Point(200, y), AutoSize = true, Font = new Font("Segoe UI", 9) };
            chkActive.Checked = true;
            pnlDetail.Controls.AddRange(new Control[] { chkPrescription, chkActive }); y += 30;

            lblError = new Label { Location = new Point(10, y), Size = new Size(355, 20), ForeColor = Color.Red, Font = new Font("Segoe UI", 9) }; y += 25;
            pnlDetail.Controls.Add(lblError);

            btnSave   = new Button { Text = "Save",   Location = new Point(10,  y), Size = new Size(160, 36), BackColor = Color.FromArgb(0,120,215), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            btnCancel = new Button { Text = "Cancel", Location = new Point(185, y), Size = new Size(160, 36), BackColor = Color.LightGray, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10) };
            btnSave.Click   += BtnSave_Click;
            btnCancel.Click += (s, e) => pnlDetail.Visible = false;
            pnlDetail.Controls.AddRange(new Control[] { btnSave, btnCancel });
            this.Controls.Add(pnlDetail);
        }

        // ── Helpers ───────────────────────────────────────────────────────────
        private Label AddLabel(Panel p, string text, int x, int y, bool bold = false, int size = 9)
        {
            var l = new Label { Text = text, Location = new Point(x, y), AutoSize = true, Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular) };
            p.Controls.Add(l); return l;
        }
        private TextBox AddTextBox(Panel p, int x, int y, int w)
        {
            var t = new TextBox { Location = new Point(x, y), Size = new Size(w, 26), Font = new Font("Segoe UI", 10), BorderStyle = BorderStyle.FixedSingle };
            p.Controls.Add(t); return t;
        }
        private ComboBox AddComboBox(Panel p, int x, int y, int w)
        {
            var c = new ComboBox { Location = new Point(x, y), Size = new Size(w, 26), Font = new Font("Segoe UI", 10), DropDownStyle = ComboBoxStyle.DropDownList };
            p.Controls.Add(c); return c;
        }

        // ── Load ──────────────────────────────────────────────────────────────
        private void LoadCombos()
        {
            var cats = _catDAL.GetAll();
            cboCategory.DataSource    = cats;
            cboCategory.DisplayMember = "CategoryName";
            cboCategory.ValueMember   = "CategoryID";

            var filterCats = new List<Category> { new Category { CategoryID = 0, CategoryName = "All Categories" } };
            filterCats.AddRange(cats);
            cboFilterCategory.DataSource    = filterCats;
            cboFilterCategory.DisplayMember = "CategoryName";
            cboFilterCategory.ValueMember   = "CategoryID";

            var sups = _supDAL.GetAll();
            sups.Insert(0, new Supplier { SupplierID = 0, SupplierName = "(None)" });
            cboSupplier.DataSource    = sups;
            cboSupplier.DisplayMember = "SupplierName";
            cboSupplier.ValueMember   = "SupplierID";
        }

        private void LoadGrid(string search = "", int? catID = null)
        {
            dgvMedicines.Rows.Clear();
            var list = string.IsNullOrWhiteSpace(search) && (catID == null || catID == 0)
                ? _medDAL.GetAll()
                : _medDAL.Search(search, catID == 0 ? null : catID);

            foreach (var m in list)
                dgvMedicines.Rows.Add(m.MedicineID, m.MedicineName, m.GenericName,
                    m.CategoryName, $"Rs {m.SalePrice:N2}", m.StockQuantity, m.UnitOfMeasure,
                    "Edit", "Delete");
        }

        private void ShowDetail(Medicine m)
        {
            _editing = m;
            lblFormTitle.Text = m == null ? "Add Medicine" : "Edit Medicine";
            lblError.Text = "";

            txtName.Text       = m?.MedicineName ?? "";
            txtGeneric.Text    = m?.GenericName  ?? "";
            txtUnitPrice.Text  = m?.UnitPrice.ToString("N2") ?? "";
            txtSalePrice.Text  = m?.SalePrice.ToString("N2") ?? "";
            txtStock.Text      = m?.StockQuantity.ToString() ?? "0";
            txtReorder.Text    = m?.ReorderLevel.ToString()  ?? "10";
            txtShelf.Text      = m?.ShelfLocation ?? "";
            chkPrescription.Checked = m?.RequiresPrescription ?? false;
            chkActive.Checked       = m?.IsActive ?? true;

            if (m != null)
            {
                cboCategory.SelectedValue = m.CategoryID;
                cboSupplier.SelectedValue = m.SupplierID ?? 0;
                cboUnit.Text = m.UnitOfMeasure;
            }
            else
            {
                cboUnit.SelectedIndex = 0;
            }

            pnlDetail.Visible = true;
            txtName.Focus();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            if (!Validator.IsNotEmpty(txtName.Text))          { lblError.Text = "Medicine name is required."; return; }
            if (!Validator.IsPositiveDecimal(txtSalePrice.Text, out decimal sp)) { lblError.Text = "Invalid sale price."; return; }
            if (!Validator.IsPositiveDecimal(txtUnitPrice.Text, out decimal up)) { lblError.Text = "Invalid unit price."; return; }
            if (!Validator.IsNonNegativeInt(txtStock.Text,   out int stock))     { lblError.Text = "Invalid stock."; return; }
            if (!Validator.IsNonNegativeInt(txtReorder.Text, out int reorder))   { lblError.Text = "Invalid reorder level."; return; }

            var m = _editing ?? new Medicine();
            m.MedicineName         = txtName.Text.Trim();
            m.GenericName          = txtGeneric.Text.Trim();
            m.CategoryID           = (int)cboCategory.SelectedValue;
            m.SupplierID           = (int)cboSupplier.SelectedValue == 0 ? (int?)null : (int)cboSupplier.SelectedValue;
            m.UnitPrice            = up;
            m.SalePrice            = sp;
            m.StockQuantity        = stock;
            m.ReorderLevel         = reorder;
            m.UnitOfMeasure        = cboUnit.Text;
            m.ShelfLocation        = txtShelf.Text.Trim();
            m.RequiresPrescription = chkPrescription.Checked;
            m.IsActive             = chkActive.Checked;

            try
            {
                bool ok = _editing == null ? _medDAL.Insert(m) : _medDAL.Update(m);
                if (ok)
                {
                    MessageBox.Show("Saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    pnlDetail.Visible = false;
                    LoadGrid();
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("MedicineForm", "Save", ex);
                lblError.Text = "Error saving medicine: " + ex.Message;
            }
        }

        private void DgvMedicines_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            int id = Convert.ToInt32(dgvMedicines.Rows[e.RowIndex].Cells["MedicineID"].Value);
            int editCol   = dgvMedicines.Columns.Count - 2;
            int deleteCol = dgvMedicines.Columns.Count - 1;

            if (e.ColumnIndex == editCol)
            {
                var med = _medDAL.GetByID(id);
                if (med != null) ShowDetail(med);
            }
            else if (e.ColumnIndex == deleteCol)
            {
                if (MessageBox.Show("Deactivate this medicine?", "Confirm",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    _medDAL.Delete(id);
                    LoadGrid();
                }
            }
        }
    }
}
