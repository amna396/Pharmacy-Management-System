using System;
using System.Collections.Generic;
using System.Data;
using MySql.Data.MySqlClient;
using PharmacyMS.Models;

namespace PharmacyMS.DAL
{
    public class SaleDAL
    {
        // ── Create full sale with items (TRANSACTION) ─────────────────────────
        public int CreateSale(Sale sale)
        {
            MySqlConnection conn = null;
            MySqlTransaction tx  = null;
            try
            {
                conn = DBConnection.Instance.GetConnection();
                tx   = conn.BeginTransaction();

                // 1. Insert sale header
                var cmdSale = new MySqlCommand(
                    @"INSERT INTO Sales (CustomerID, UserID, PrescriptionID, PaymentMethod,
                                        DiscountAmount, TotalAmount, NetAmount, Notes)
                      VALUES (@ci, @ui, @pi, @pm, @da, @ta, @na, @no);
                      SELECT LAST_INSERT_ID();", conn, tx);

                cmdSale.Parameters.AddWithValue("@ci", sale.CustomerID.HasValue    ? (object)sale.CustomerID.Value    : DBNull.Value);
                cmdSale.Parameters.AddWithValue("@ui", sale.UserID);
                cmdSale.Parameters.AddWithValue("@pi", sale.PrescriptionID.HasValue ? (object)sale.PrescriptionID.Value : DBNull.Value);
                cmdSale.Parameters.AddWithValue("@pm", sale.PaymentMethod);
                cmdSale.Parameters.AddWithValue("@da", sale.DiscountAmount);
                cmdSale.Parameters.AddWithValue("@ta", sale.TotalAmount);
                cmdSale.Parameters.AddWithValue("@na", sale.NetAmount);
                cmdSale.Parameters.AddWithValue("@no", sale.Notes ?? (object)DBNull.Value);

                int saleID = Convert.ToInt32(cmdSale.ExecuteScalar());

                // 2. Insert each sale item
                foreach (var item in sale.Items)
                {
                    // Check stock
                    var cmdStock = new MySqlCommand(
                        "SELECT StockQuantity FROM Medicines WHERE MedicineID=@mid", conn, tx);
                    cmdStock.Parameters.AddWithValue("@mid", item.MedicineID);
                    int stock = Convert.ToInt32(cmdStock.ExecuteScalar());

                    if (stock < item.Quantity)
                        throw new Exception($"Insufficient stock for medicine ID {item.MedicineID}. Available: {stock}");

                    var cmdItem = new MySqlCommand(
                        @"INSERT INTO SaleItems (SaleID, MedicineID, Quantity, UnitPrice, Discount, SubTotal)
                          VALUES (@sid, @mid, @qty, @up, @dis, @sub)", conn, tx);
                    cmdItem.Parameters.AddWithValue("@sid", saleID);
                    cmdItem.Parameters.AddWithValue("@mid", item.MedicineID);
                    cmdItem.Parameters.AddWithValue("@qty", item.Quantity);
                    cmdItem.Parameters.AddWithValue("@up",  item.UnitPrice);
                    cmdItem.Parameters.AddWithValue("@dis", item.Discount);
                    cmdItem.Parameters.AddWithValue("@sub", item.SubTotal);
                    cmdItem.ExecuteNonQuery();

                    // Deduct stock
                    var cmdDeduct = new MySqlCommand(
                        "UPDATE Medicines SET StockQuantity = StockQuantity - @qty WHERE MedicineID=@mid",
                        conn, tx);
                    cmdDeduct.Parameters.AddWithValue("@qty", item.Quantity);
                    cmdDeduct.Parameters.AddWithValue("@mid", item.MedicineID);
                    cmdDeduct.ExecuteNonQuery();
                }

                tx.Commit();
                return saleID;
            }
            catch
            {
                tx?.Rollback();
                throw;
            }
            finally
            {
                conn?.Close();
            }
        }

        // ── Get sale with items ───────────────────────────────────────────────
        public Sale GetByID(int saleID)
        {
            Sale sale = null;
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                {
                    using (var cmd = new MySqlCommand(
                        @"SELECT s.*, COALESCE(c.FullName,'Walk-in') AS CustomerName,
                                 u.FullName AS CashierName
                          FROM Sales s
                          LEFT JOIN Customers c ON s.CustomerID = c.CustomerID
                          JOIN Users u ON s.UserID = u.UserID
                          WHERE s.SaleID = @id", conn))
                    {
                        cmd.Parameters.AddWithValue("@id", saleID);
                        using (var rd = cmd.ExecuteReader())
                            if (rd.Read()) sale = MapSale(rd);
                    }

                    if (sale != null)
                    {
                        using (var cmd2 = new MySqlCommand(
                            @"SELECT si.*, m.MedicineName
                              FROM SaleItems si
                              JOIN Medicines m ON si.MedicineID = m.MedicineID
                              WHERE si.SaleID = @id", conn))
                        {
                            cmd2.Parameters.AddWithValue("@id", saleID);
                            using (var rd = cmd2.ExecuteReader())
                                while (rd.Read())
                                    sale.Items.Add(new SaleItem
                                    {
                                        SaleItemID   = rd.GetInt32("SaleItemID"),
                                        SaleID       = saleID,
                                        MedicineID   = rd.GetInt32("MedicineID"),
                                        MedicineName = rd.GetString("MedicineName"),
                                        Quantity     = rd.GetInt32("Quantity"),
                                        UnitPrice    = rd.GetDecimal("UnitPrice"),
                                        Discount     = rd.GetDecimal("Discount"),
                                        SubTotal     = rd.GetDecimal("SubTotal")
                                    });
                        }
                    }
                }
            }
            catch (Exception ex) { Logger.LogError("SaleDAL", "GetByID", ex); throw; }
            return sale;
        }

        // ── Get sales by date range ───────────────────────────────────────────
        public DataTable GetByDateRange(DateTime from, DateTime to)
        {
            var dt = new DataTable();
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var ada = new MySqlDataAdapter(
                    @"SELECT s.SaleID, s.SaleDate,
                             COALESCE(c.FullName,'Walk-in') AS Customer,
                             u.FullName AS Cashier,
                             s.TotalAmount, s.DiscountAmount, s.NetAmount,
                             s.PaymentMethod, s.PaymentStatus
                      FROM Sales s
                      LEFT JOIN Customers c ON s.CustomerID = c.CustomerID
                      JOIN Users u ON s.UserID = u.UserID
                      WHERE DATE(s.SaleDate) BETWEEN @f AND @t
                      ORDER BY s.SaleDate DESC", conn))
                {
                    ada.SelectCommand.Parameters.AddWithValue("@f", from.Date);
                    ada.SelectCommand.Parameters.AddWithValue("@t", to.Date);
                    ada.Fill(dt);
                }
            }
            catch (Exception ex) { Logger.LogError("SaleDAL", "GetByDateRange", ex); throw; }
            return dt;
        }

        // ── Today summary ─────────────────────────────────────────────────────
        public Tuple<int, decimal> GetTodaySummary()
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"SELECT COUNT(*) AS Cnt, COALESCE(SUM(NetAmount),0) AS Rev
                      FROM Sales WHERE DATE(SaleDate)=CURDATE() AND PaymentStatus='Paid'", conn))
                using (var rd = cmd.ExecuteReader())
                    if (rd.Read())
                        return Tuple.Create(rd.GetInt32("Cnt"), rd.GetDecimal("Rev"));
            }
            catch (Exception ex) { Logger.LogError("SaleDAL", "GetTodaySummary", ex); }
            return Tuple.Create(0, 0m);
        }

        private Sale MapSale(MySqlDataReader rd) => new Sale
        {
            SaleID         = rd.GetInt32("SaleID"),
            CustomerID     = rd.IsDBNull(rd.GetOrdinal("CustomerID")) ? (int?)null : rd.GetInt32("CustomerID"),
            CustomerName   = rd.GetString("CustomerName"),
            UserID         = rd.GetInt32("UserID"),
            CashierName    = rd.GetString("CashierName"),
            SaleDate       = rd.GetDateTime("SaleDate"),
            TotalAmount    = rd.GetDecimal("TotalAmount"),
            DiscountAmount = rd.GetDecimal("DiscountAmount"),
            NetAmount      = rd.GetDecimal("NetAmount"),
            PaymentMethod  = rd.GetString("PaymentMethod"),
            PaymentStatus  = rd.GetString("PaymentStatus"),
            Notes          = rd.IsDBNull(rd.GetOrdinal("Notes")) ? "" : rd.GetString("Notes")
        };
    }
}
