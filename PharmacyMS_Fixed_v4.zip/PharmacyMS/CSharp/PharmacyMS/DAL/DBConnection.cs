using System;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace PharmacyMS.DAL
{
    /// <summary>
    /// Manages MySQL database connections for the Pharmacy Management System.
    /// Uses connection string from App.config.
    /// </summary>
    public class DBConnection
    {
        // ── Singleton ────────────────────────────────────────────────────────
        private static DBConnection _instance;
        public  static DBConnection Instance
        {
            get
            {
                if (_instance == null) _instance = new DBConnection();
                return _instance;
            }
        }

        // ── Connection string (edit App.config to change credentials) ────────
        private readonly string _connectionString =
            ConfigurationManager.ConnectionStrings["PharmacyDB"].ConnectionString;

        private DBConnection() { }

        // ── Open a fresh connection ───────────────────────────────────────────
        public MySqlConnection GetConnection()
        {
            try
            {
                var conn = new MySqlConnection(_connectionString);
                conn.Open();
                return conn;
            }
            catch (Exception ex)
            {
                Logger.LogError("DBConnection", "GetConnection", ex);
                throw;
            }
        }

        // ── Test connection (used on startup) ────────────────────────────────
        public bool TestConnection()
        {
            try
            {
                using (var conn = GetConnection())
                    return conn.State == System.Data.ConnectionState.Open;
            }
            catch
            {
                return false;
            }
        }
    }
}
