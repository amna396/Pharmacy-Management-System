using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using PharmacyMS.Models;

namespace PharmacyMS.DAL
{
    // ══════════════════════════════════════════════════════════════════════════
    //  CategoryDAL
    // ══════════════════════════════════════════════════════════════════════════
    public class CategoryDAL
    {
        public List<Category> GetAll(bool activeOnly = true)
        {
            var list = new List<Category>();
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    "SELECT * FROM Categories WHERE (@ao=0 OR IsActive=1) ORDER BY CategoryName", conn))
                {
                    cmd.Parameters.AddWithValue("@ao", activeOnly ? 1 : 0);
                    using (var rd = cmd.ExecuteReader())
                        while (rd.Read())
                            list.Add(new Category
                            {
                                CategoryID   = rd.GetInt32("CategoryID"),
                                CategoryName = rd.GetString("CategoryName"),
                                Description  = rd.IsDBNull(rd.GetOrdinal("Description")) ? "" : rd.GetString("Description"),
                                IsActive     = rd.GetBoolean("IsActive")
                            });
                }
            }
            catch (Exception ex) { Logger.LogError("CategoryDAL", "GetAll", ex); throw; }
            return list;
        }

        public bool Insert(Category c)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    "INSERT INTO Categories (CategoryName, Description, IsActive) VALUES (@cn, @d, @ia)", conn))
                {
                    cmd.Parameters.AddWithValue("@cn", c.CategoryName);
                    cmd.Parameters.AddWithValue("@d",  c.Description ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@ia", c.IsActive);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("CategoryDAL", "Insert", ex); throw; }
        }

        public bool Update(Category c)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    "UPDATE Categories SET CategoryName=@cn, Description=@d, IsActive=@ia WHERE CategoryID=@id", conn))
                {
                    cmd.Parameters.AddWithValue("@cn", c.CategoryName);
                    cmd.Parameters.AddWithValue("@d",  c.Description ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@ia", c.IsActive);
                    cmd.Parameters.AddWithValue("@id", c.CategoryID);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("CategoryDAL", "Update", ex); throw; }
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SupplierDAL
    // ══════════════════════════════════════════════════════════════════════════
    public class SupplierDAL
    {
        public List<Supplier> GetAll(bool activeOnly = true)
        {
            var list = new List<Supplier>();
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    "SELECT * FROM Suppliers WHERE (@ao=0 OR IsActive=1) ORDER BY SupplierName", conn))
                {
                    cmd.Parameters.AddWithValue("@ao", activeOnly ? 1 : 0);
                    using (var rd = cmd.ExecuteReader())
                        while (rd.Read())
                            list.Add(MapSupplier(rd));
                }
            }
            catch (Exception ex) { Logger.LogError("SupplierDAL", "GetAll", ex); throw; }
            return list;
        }

        public bool Insert(Supplier s)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"INSERT INTO Suppliers (SupplierName, ContactName, Email, Phone, Address, City, Country, IsActive)
                      VALUES (@sn, @cn, @em, @ph, @ad, @ci, @co, @ia)", conn))
                {
                    SetParams(cmd, s);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("SupplierDAL", "Insert", ex); throw; }
        }

        public bool Update(Supplier s)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"UPDATE Suppliers SET SupplierName=@sn, ContactName=@cn, Email=@em,
                        Phone=@ph, Address=@ad, City=@ci, Country=@co, IsActive=@ia
                      WHERE SupplierID=@id", conn))
                {
                    SetParams(cmd, s);
                    cmd.Parameters.AddWithValue("@id", s.SupplierID);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("SupplierDAL", "Update", ex); throw; }
        }

        private void SetParams(MySqlCommand cmd, Supplier s)
        {
            cmd.Parameters.AddWithValue("@sn", s.SupplierName);
            cmd.Parameters.AddWithValue("@cn", s.ContactName  ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@em", s.Email        ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@ph", s.Phone);
            cmd.Parameters.AddWithValue("@ad", s.Address      ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@ci", s.City         ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@co", s.Country      ?? "Pakistan");
            cmd.Parameters.AddWithValue("@ia", s.IsActive);
        }

        private Supplier MapSupplier(MySqlDataReader rd) => new Supplier
        {
            SupplierID   = rd.GetInt32("SupplierID"),
            SupplierName = rd.GetString("SupplierName"),
            ContactName  = rd.IsDBNull(rd.GetOrdinal("ContactName")) ? "" : rd.GetString("ContactName"),
            Email        = rd.IsDBNull(rd.GetOrdinal("Email"))       ? "" : rd.GetString("Email"),
            Phone        = rd.GetString("Phone"),
            Address      = rd.IsDBNull(rd.GetOrdinal("Address"))     ? "" : rd.GetString("Address"),
            City         = rd.IsDBNull(rd.GetOrdinal("City"))        ? "" : rd.GetString("City"),
            Country      = rd.IsDBNull(rd.GetOrdinal("Country"))     ? "" : rd.GetString("Country"),
            IsActive     = rd.GetBoolean("IsActive")
        };
    }
}
