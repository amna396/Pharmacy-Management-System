using System;
using System.Collections.Generic;
using System.Data;
using MySql.Data.MySqlClient;
using PharmacyMS.Models;

namespace PharmacyMS.DAL
{
    public class MedicineDAL
    {
        // ── GetAll ────────────────────────────────────────────────────────────
        public List<Medicine> GetAll(bool activeOnly = true)
        {
            var list = new List<Medicine>();
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"SELECT m.*, c.CategoryName, s.SupplierName
                      FROM Medicines m
                      JOIN Categories c ON m.CategoryID = c.CategoryID
                      LEFT JOIN Suppliers s ON m.SupplierID = s.SupplierID
                      WHERE (@activeOnly = 0 OR m.IsActive = 1)
                      ORDER BY m.MedicineName", conn))
                {
                    cmd.Parameters.AddWithValue("@activeOnly", activeOnly ? 1 : 0);
                    using (var rd = cmd.ExecuteReader())
                        while (rd.Read()) list.Add(MapMedicine(rd));
                }
            }
            catch (Exception ex) { Logger.LogError("MedicineDAL", "GetAll", ex); throw; }
            return list;
        }

        // ── Search ────────────────────────────────────────────────────────────
        public List<Medicine> Search(string term, int? categoryID = null)
        {
            var list = new List<Medicine>();
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand("CALL sp_SearchMedicines(@term, @cat)", conn))
                {
                    cmd.Parameters.AddWithValue("@term", string.IsNullOrWhiteSpace(term) ? (object)DBNull.Value : term);
                    cmd.Parameters.AddWithValue("@cat",  categoryID.HasValue ? (object)categoryID.Value : DBNull.Value);
                    using (var rd = cmd.ExecuteReader())
                        while (rd.Read())
                            list.Add(new Medicine
                            {
                                MedicineID           = rd.GetInt32("MedicineID"),
                                MedicineName         = rd.GetString("MedicineName"),
                                GenericName          = rd.IsDBNull(rd.GetOrdinal("GenericName")) ? "" : rd.GetString("GenericName"),
                                CategoryName         = rd.GetString("CategoryName"),
                                SalePrice            = rd.GetDecimal("SalePrice"),
                                StockQuantity        = rd.GetInt32("StockQuantity"),
                                UnitOfMeasure        = rd.GetString("UnitOfMeasure"),
                                RequiresPrescription = rd.GetBoolean("RequiresPrescription")
                            });
                }
            }
            catch (Exception ex) { Logger.LogError("MedicineDAL", "Search", ex); throw; }
            return list;
        }

        // ── GetByID ───────────────────────────────────────────────────────────
        public Medicine GetByID(int id)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"SELECT m.*, c.CategoryName, s.SupplierName
                      FROM Medicines m
                      JOIN Categories c ON m.CategoryID = c.CategoryID
                      LEFT JOIN Suppliers s ON m.SupplierID = s.SupplierID
                      WHERE m.MedicineID = @id", conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    using (var rd = cmd.ExecuteReader())
                        if (rd.Read()) return MapMedicine(rd);
                }
            }
            catch (Exception ex) { Logger.LogError("MedicineDAL", "GetByID", ex); throw; }
            return null;
        }

        // ── Insert ────────────────────────────────────────────────────────────
        public bool Insert(Medicine m)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"INSERT INTO Medicines
                        (MedicineName, GenericName, CategoryID, SupplierID,
                         UnitPrice, SalePrice, StockQuantity, ReorderLevel,
                         UnitOfMeasure, RequiresPrescription, ShelfLocation, IsActive)
                      VALUES
                        (@mn, @gn, @ci, @si, @up, @sp, @sq, @rl, @um, @rp, @sl, @ia)", conn))
                {
                    SetParams(cmd, m);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("MedicineDAL", "Insert", ex); throw; }
        }

        // ── Update ────────────────────────────────────────────────────────────
        public bool Update(Medicine m)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"UPDATE Medicines SET
                        MedicineName=@mn, GenericName=@gn, CategoryID=@ci,
                        SupplierID=@si, UnitPrice=@up, SalePrice=@sp,
                        StockQuantity=@sq, ReorderLevel=@rl, UnitOfMeasure=@um,
                        RequiresPrescription=@rp, ShelfLocation=@sl, IsActive=@ia
                      WHERE MedicineID=@id", conn))
                {
                    SetParams(cmd, m);
                    cmd.Parameters.AddWithValue("@id", m.MedicineID);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("MedicineDAL", "Update", ex); throw; }
        }

        // ── Delete (soft) ─────────────────────────────────────────────────────
        public bool Delete(int id)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    "UPDATE Medicines SET IsActive=0 WHERE MedicineID=@id", conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("MedicineDAL", "Delete", ex); throw; }
        }

        // ── Low Stock ─────────────────────────────────────────────────────────
        public DataTable GetLowStock()
        {
            var dt = new DataTable();
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var ada = new MySqlDataAdapter("SELECT * FROM vw_LowStockMedicines", conn))
                    ada.Fill(dt);
            }
            catch (Exception ex) { Logger.LogError("MedicineDAL", "GetLowStock", ex); throw; }
            return dt;
        }

        // ── Helpers ───────────────────────────────────────────────────────────
        private void SetParams(MySqlCommand cmd, Medicine m)
        {
            cmd.Parameters.AddWithValue("@mn", m.MedicineName);
            cmd.Parameters.AddWithValue("@gn", m.GenericName ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@ci", m.CategoryID);
            cmd.Parameters.AddWithValue("@si", m.SupplierID.HasValue ? (object)m.SupplierID.Value : DBNull.Value);
            cmd.Parameters.AddWithValue("@up", m.UnitPrice);
            cmd.Parameters.AddWithValue("@sp", m.SalePrice);
            cmd.Parameters.AddWithValue("@sq", m.StockQuantity);
            cmd.Parameters.AddWithValue("@rl", m.ReorderLevel);
            cmd.Parameters.AddWithValue("@um", m.UnitOfMeasure ?? "Tablets");
            cmd.Parameters.AddWithValue("@rp", m.RequiresPrescription);
            cmd.Parameters.AddWithValue("@sl", m.ShelfLocation ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@ia", m.IsActive);
        }

        private Medicine MapMedicine(MySqlDataReader rd) => new Medicine
        {
            MedicineID           = rd.GetInt32("MedicineID"),
            MedicineName         = rd.GetString("MedicineName"),
            GenericName          = rd.IsDBNull(rd.GetOrdinal("GenericName"))    ? "" : rd.GetString("GenericName"),
            CategoryID           = rd.GetInt32("CategoryID"),
            CategoryName         = rd.GetString("CategoryName"),
            SupplierID           = rd.IsDBNull(rd.GetOrdinal("SupplierID"))     ? (int?)null : rd.GetInt32("SupplierID"),
            SupplierName         = rd.IsDBNull(rd.GetOrdinal("SupplierName"))   ? "" : rd.GetString("SupplierName"),
            UnitPrice            = rd.GetDecimal("UnitPrice"),
            SalePrice            = rd.GetDecimal("SalePrice"),
            StockQuantity        = rd.GetInt32("StockQuantity"),
            ReorderLevel         = rd.GetInt32("ReorderLevel"),
            UnitOfMeasure        = rd.GetString("UnitOfMeasure"),
            RequiresPrescription = rd.GetBoolean("RequiresPrescription"),
            ShelfLocation        = rd.IsDBNull(rd.GetOrdinal("ShelfLocation"))  ? "" : rd.GetString("ShelfLocation"),
            IsActive             = rd.GetBoolean("IsActive")
        };
    }
}
