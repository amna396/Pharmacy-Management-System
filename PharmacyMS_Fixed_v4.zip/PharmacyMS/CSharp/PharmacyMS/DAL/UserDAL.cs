using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using PharmacyMS.Models;

namespace PharmacyMS.DAL
{
    public class UserDAL
    {
        // ── Login ─────────────────────────────────────────────────────────────
        public User GetByUsernameAndPassword(string username, string passwordHash)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"SELECT u.UserID, u.Username, u.FullName, u.Email, u.Phone,
                             u.RoleID, r.RoleName, u.IsActive, u.LastLogin
                      FROM Users u
                      JOIN Roles r ON u.RoleID = r.RoleID
                      WHERE u.Username = @uname
                        AND u.PasswordHash = @pwd
                        AND u.IsActive = 1", conn))
                {
                    cmd.Parameters.AddWithValue("@uname", username);
                    cmd.Parameters.AddWithValue("@pwd",   passwordHash);

                    using (var rd = cmd.ExecuteReader())
                    {
                        if (rd.Read())
                            return MapUser(rd);
                    }
                }
            }
            catch (Exception ex) { Logger.LogError("UserDAL", "GetByUsernameAndPassword", ex); throw; }
            return null;
        }

        // ── Update LastLogin ──────────────────────────────────────────────────
        public void UpdateLastLogin(int userID)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    "UPDATE Users SET LastLogin = NOW() WHERE UserID = @id", conn))
                {
                    cmd.Parameters.AddWithValue("@id", userID);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex) { Logger.LogError("UserDAL", "UpdateLastLogin", ex); }
        }

        // ── GetAll ────────────────────────────────────────────────────────────
        public List<User> GetAll()
        {
            var list = new List<User>();
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"SELECT u.UserID, u.Username, u.FullName, u.Email, u.Phone,
                             u.RoleID, r.RoleName, u.IsActive, u.LastLogin
                      FROM Users u JOIN Roles r ON u.RoleID = r.RoleID
                      ORDER BY u.FullName", conn))
                using (var rd = cmd.ExecuteReader())
                    while (rd.Read()) list.Add(MapUser(rd));
            }
            catch (Exception ex) { Logger.LogError("UserDAL", "GetAll", ex); throw; }
            return list;
        }

        // ── Insert ────────────────────────────────────────────────────────────
        public bool Insert(User u)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"INSERT INTO Users (Username, PasswordHash, FullName, Email, Phone, RoleID, IsActive)
                      VALUES (@un, @ph, @fn, @em, @pn, @ri, @ia)", conn))
                {
                    cmd.Parameters.AddWithValue("@un", u.Username);
                    cmd.Parameters.AddWithValue("@ph", u.PasswordHash);
                    cmd.Parameters.AddWithValue("@fn", u.FullName);
                    cmd.Parameters.AddWithValue("@em", u.Email);
                    cmd.Parameters.AddWithValue("@pn", u.Phone);
                    cmd.Parameters.AddWithValue("@ri", u.RoleID);
                    cmd.Parameters.AddWithValue("@ia", u.IsActive);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("UserDAL", "Insert", ex); throw; }
        }

        // ── Update ────────────────────────────────────────────────────────────
        public bool Update(User u)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"UPDATE Users SET FullName=@fn, Email=@em, Phone=@pn,
                                      RoleID=@ri, IsActive=@ia
                      WHERE UserID=@id", conn))
                {
                    cmd.Parameters.AddWithValue("@fn", u.FullName);
                    cmd.Parameters.AddWithValue("@em", u.Email);
                    cmd.Parameters.AddWithValue("@pn", u.Phone);
                    cmd.Parameters.AddWithValue("@ri", u.RoleID);
                    cmd.Parameters.AddWithValue("@ia", u.IsActive);
                    cmd.Parameters.AddWithValue("@id", u.UserID);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("UserDAL", "Update", ex); throw; }
        }

        // ── Change Password ───────────────────────────────────────────────────
        public bool ChangePassword(int userID, string newHash)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    "UPDATE Users SET PasswordHash=@ph WHERE UserID=@id", conn))
                {
                    cmd.Parameters.AddWithValue("@ph", newHash);
                    cmd.Parameters.AddWithValue("@id", userID);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("UserDAL", "ChangePassword", ex); throw; }
        }

        // ── Get Roles ─────────────────────────────────────────────────────────
        public List<Role> GetRoles()
        {
            var list = new List<Role>();
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand("SELECT RoleID, RoleName FROM Roles ORDER BY RoleName", conn))
                using (var rd = cmd.ExecuteReader())
                    while (rd.Read())
                        list.Add(new Role { RoleID = rd.GetInt32(0), RoleName = rd.GetString(1) });
            }
            catch (Exception ex) { Logger.LogError("UserDAL", "GetRoles", ex); throw; }
            return list;
        }

        // ── Map ───────────────────────────────────────────────────────────────
        private User MapUser(MySqlDataReader rd) => new User
        {
            UserID    = rd.GetInt32("UserID"),
            Username  = rd.GetString("Username"),
            FullName  = rd.GetString("FullName"),
            Email     = rd.GetString("Email"),
            Phone     = rd.IsDBNull(rd.GetOrdinal("Phone")) ? "" : rd.GetString("Phone"),
            RoleID    = rd.GetInt32("RoleID"),
            RoleName  = rd.GetString("RoleName"),
            IsActive  = rd.GetBoolean("IsActive"),
            LastLogin = rd.IsDBNull(rd.GetOrdinal("LastLogin")) ? (DateTime?)null : rd.GetDateTime("LastLogin")
        };
    }
}
