using System;
using System.Collections.Generic;
using System.Data;
using MySql.Data.MySqlClient;
using PharmacyMS.Models;

namespace PharmacyMS.DAL
{
    public class PurchaseOrderDAL
    {
        public DataTable GetAll()
        {
            var dt = new DataTable();
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var ada = new MySqlDataAdapter("SELECT * FROM vw_PurchaseOrderOverview ORDER BY OrderDate DESC", conn))
                    ada.Fill(dt);
            }
            catch (Exception ex) { Logger.LogError("PurchaseOrderDAL", "GetAll", ex); throw; }
            return dt;
        }

        public int Insert(PurchaseOrder po)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"INSERT INTO PurchaseOrders (SupplierID, OrderedByUserID, ExpectedDate, Notes, Status)
                      VALUES (@si, @ui, @ed, @no, 'Pending');
                      SELECT LAST_INSERT_ID();", conn))
                {
                    cmd.Parameters.AddWithValue("@si", po.SupplierID);
                    cmd.Parameters.AddWithValue("@ui", po.OrderedByUserID);
                    cmd.Parameters.AddWithValue("@ed", po.ExpectedDate.HasValue ? (object)po.ExpectedDate.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@no", po.Notes ?? (object)DBNull.Value);
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
            catch (Exception ex) { Logger.LogError("PurchaseOrderDAL", "Insert", ex); throw; }
        }

        public bool AddItem(int poID, int medicineID, int qty, decimal cost, DateTime? expiry, string batch)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"INSERT INTO PurchaseOrderItems (POID, MedicineID, Quantity, UnitCost, SubTotal, ExpiryDate, BatchNumber)
                      VALUES (@po, @mi, @qt, @uc, @st, @ex, @bn)", conn))
                {
                    cmd.Parameters.AddWithValue("@po", poID);
                    cmd.Parameters.AddWithValue("@mi", medicineID);
                    cmd.Parameters.AddWithValue("@qt", qty);
                    cmd.Parameters.AddWithValue("@uc", cost);
                    cmd.Parameters.AddWithValue("@st", qty * cost);
                    cmd.Parameters.AddWithValue("@ex", expiry.HasValue ? (object)expiry.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@bn", batch ?? (object)DBNull.Value);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("PurchaseOrderDAL", "AddItem", ex); throw; }
        }

        public bool UpdateStatus(int poID, string status)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    "UPDATE PurchaseOrders SET Status=@st WHERE POID=@id", conn))
                {
                    cmd.Parameters.AddWithValue("@st", status);
                    cmd.Parameters.AddWithValue("@id", poID);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("PurchaseOrderDAL", "UpdateStatus", ex); throw; }
        }

        /// <summary>Receive order: updates stock via stored procedure (uses transaction inside SP).</summary>
        public string ReceiveOrder(int poID, int userID)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand("CALL sp_ReceivePurchaseOrder(@po, @ui, @msg)", conn))
                {
                    cmd.Parameters.AddWithValue("@po", poID);
                    cmd.Parameters.AddWithValue("@ui", userID);
                    var msgParam = cmd.Parameters.AddWithValue("@msg", "");
                    msgParam.Direction = System.Data.ParameterDirection.Output;
                    msgParam.Size = 200;
                    cmd.ExecuteNonQuery();
                    return msgParam.Value?.ToString();
                }
            }
            catch (Exception ex) { Logger.LogError("PurchaseOrderDAL", "ReceiveOrder", ex); throw; }
        }
    }
}
