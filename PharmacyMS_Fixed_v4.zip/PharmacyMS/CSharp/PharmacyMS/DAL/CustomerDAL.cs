using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using PharmacyMS.Models;

namespace PharmacyMS.DAL
{
    public class CustomerDAL
    {
        public List<Customer> GetAll()
        {
            var list = new List<Customer>();
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    "SELECT * FROM Customers ORDER BY FullName", conn))
                using (var rd = cmd.ExecuteReader())
                    while (rd.Read()) list.Add(MapCustomer(rd));
            }
            catch (Exception ex) { Logger.LogError("CustomerDAL", "GetAll", ex); throw; }
            return list;
        }

        public List<Customer> Search(string term)
        {
            var list = new List<Customer>();
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"SELECT * FROM Customers
                      WHERE FullName LIKE @t OR Phone LIKE @t OR Email LIKE @t
                      ORDER BY FullName", conn))
                {
                    cmd.Parameters.AddWithValue("@t", $"%{term}%");
                    using (var rd = cmd.ExecuteReader())
                        while (rd.Read()) list.Add(MapCustomer(rd));
                }
            }
            catch (Exception ex) { Logger.LogError("CustomerDAL", "Search", ex); throw; }
            return list;
        }

        public int Insert(Customer c)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"INSERT INTO Customers (FullName, Phone, Email, Address, DateOfBirth, Gender, MedicalNotes)
                      VALUES (@fn, @ph, @em, @ad, @dob, @ge, @mn);
                      SELECT LAST_INSERT_ID();", conn))
                {
                    SetParams(cmd, c);
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
            catch (Exception ex) { Logger.LogError("CustomerDAL", "Insert", ex); throw; }
        }

        public bool Update(Customer c)
        {
            try
            {
                using (var conn = DBConnection.Instance.GetConnection())
                using (var cmd = new MySqlCommand(
                    @"UPDATE Customers SET FullName=@fn, Phone=@ph, Email=@em,
                        Address=@ad, DateOfBirth=@dob, Gender=@ge, MedicalNotes=@mn
                      WHERE CustomerID=@id", conn))
                {
                    SetParams(cmd, c);
                    cmd.Parameters.AddWithValue("@id", c.CustomerID);
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex) { Logger.LogError("CustomerDAL", "Update", ex); throw; }
        }

        private void SetParams(MySqlCommand cmd, Customer c)
        {
            cmd.Parameters.AddWithValue("@fn",  c.FullName);
            cmd.Parameters.AddWithValue("@ph",  c.Phone        ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@em",  c.Email        ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@ad",  c.Address      ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@dob", c.DateOfBirth.HasValue ? (object)c.DateOfBirth.Value : DBNull.Value);
            cmd.Parameters.AddWithValue("@ge",  c.Gender       ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@mn",  c.MedicalNotes ?? (object)DBNull.Value);
        }

        private Customer MapCustomer(MySqlDataReader rd) => new Customer
        {
            CustomerID   = rd.GetInt32("CustomerID"),
            FullName     = rd.GetString("FullName"),
            Phone        = rd.IsDBNull(rd.GetOrdinal("Phone"))        ? "" : rd.GetString("Phone"),
            Email        = rd.IsDBNull(rd.GetOrdinal("Email"))        ? "" : rd.GetString("Email"),
            Address      = rd.IsDBNull(rd.GetOrdinal("Address"))      ? "" : rd.GetString("Address"),
            DateOfBirth  = rd.IsDBNull(rd.GetOrdinal("DateOfBirth"))  ? (DateTime?)null : rd.GetDateTime("DateOfBirth"),
            Gender       = rd.IsDBNull(rd.GetOrdinal("Gender"))       ? "" : rd.GetString("Gender"),
            MedicalNotes = rd.IsDBNull(rd.GetOrdinal("MedicalNotes")) ? "" : rd.GetString("MedicalNotes"),
            CreatedAt    = rd.GetDateTime("CreatedAt")
        };
    }
}
