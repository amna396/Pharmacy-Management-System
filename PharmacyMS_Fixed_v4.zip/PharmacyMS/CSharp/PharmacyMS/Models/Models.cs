using System;
using System.Collections.Generic;

namespace PharmacyMS.Models
{
    // ── 1. Role ───────────────────────────────────────────────────────────────
    public class Role
    {
        public int    RoleID      { get; set; }
        public string RoleName    { get; set; }
        public string Description { get; set; }
    }

    // ── 2. User ───────────────────────────────────────────────────────────────
    public class User
    {
        public int      UserID       { get; set; }
        public string   Username     { get; set; }
        public string   PasswordHash { get; set; }
        public string   FullName     { get; set; }
        public string   Email        { get; set; }
        public string   Phone        { get; set; }
        public int      RoleID       { get; set; }
        public string   RoleName     { get; set; }   // joined
        public bool     IsActive     { get; set; }
        public DateTime CreatedAt    { get; set; }
        public DateTime? LastLogin   { get; set; }
    }

    // ── 3. Category ───────────────────────────────────────────────────────────
    public class Category
    {
        public int    CategoryID   { get; set; }
        public string CategoryName { get; set; }
        public string Description  { get; set; }
        public bool   IsActive     { get; set; }
    }

    // ── 4. Supplier ───────────────────────────────────────────────────────────
    public class Supplier
    {
        public int    SupplierID   { get; set; }
        public string SupplierName { get; set; }
        public string ContactName  { get; set; }
        public string Email        { get; set; }
        public string Phone        { get; set; }
        public string Address      { get; set; }
        public string City         { get; set; }
        public string Country      { get; set; }
        public bool   IsActive     { get; set; }
    }

    // ── 5. Medicine ───────────────────────────────────────────────────────────
    public class Medicine
    {
        public int     MedicineID           { get; set; }
        public string  MedicineName         { get; set; }
        public string  GenericName          { get; set; }
        public int     CategoryID           { get; set; }
        public string  CategoryName         { get; set; }  // joined
        public int?    SupplierID           { get; set; }
        public string  SupplierName         { get; set; }  // joined
        public decimal UnitPrice            { get; set; }
        public decimal SalePrice            { get; set; }
        public int     StockQuantity        { get; set; }
        public int     ReorderLevel         { get; set; }
        public string  UnitOfMeasure        { get; set; }
        public bool    RequiresPrescription { get; set; }
        public string  ShelfLocation        { get; set; }
        public bool    IsActive             { get; set; }
        public DateTime CreatedAt           { get; set; }
    }

    // ── 6. Customer ───────────────────────────────────────────────────────────
    public class Customer
    {
        public int      CustomerID   { get; set; }
        public string   FullName     { get; set; }
        public string   Phone        { get; set; }
        public string   Email        { get; set; }
        public string   Address      { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string   Gender       { get; set; }
        public string   MedicalNotes { get; set; }
        public DateTime CreatedAt    { get; set; }
    }

    // ── 7. Prescription ───────────────────────────────────────────────────────
    public class Prescription
    {
        public int      PrescriptionID  { get; set; }
        public int      CustomerID      { get; set; }
        public string   CustomerName    { get; set; }  // joined
        public string   DoctorName      { get; set; }
        public string   DoctorPhone     { get; set; }
        public DateTime IssuedDate      { get; set; }
        public DateTime? ExpiryDate     { get; set; }
        public string   Notes           { get; set; }
        public string   ScannedFilePath { get; set; }
        public DateTime CreatedAt       { get; set; }
    }

    // ── 8. SaleItem ───────────────────────────────────────────────────────────
    public class SaleItem
    {
        public int     SaleItemID  { get; set; }
        public int     SaleID      { get; set; }
        public int     MedicineID  { get; set; }
        public string  MedicineName { get; set; }   // joined
        public int     Quantity    { get; set; }
        public decimal UnitPrice   { get; set; }
        public decimal Discount    { get; set; }
        public decimal SubTotal    { get; set; }
    }

    // ── 9. Sale ───────────────────────────────────────────────────────────────
    public class Sale
    {
        public int      SaleID          { get; set; }
        public int?     CustomerID      { get; set; }
        public string   CustomerName    { get; set; }   // joined
        public int      UserID          { get; set; }
        public string   CashierName     { get; set; }   // joined
        public int?     PrescriptionID  { get; set; }
        public DateTime SaleDate        { get; set; }
        public decimal  TotalAmount     { get; set; }
        public decimal  DiscountAmount  { get; set; }
        public decimal  NetAmount       { get; set; }
        public string   PaymentMethod   { get; set; }
        public string   PaymentStatus   { get; set; }
        public string   Notes           { get; set; }

        public List<SaleItem> Items { get; set; } = new List<SaleItem>();
    }

    // ── 10. PurchaseOrder ─────────────────────────────────────────────────────
    public class PurchaseOrder
    {
        public int      POID             { get; set; }
        public int      SupplierID       { get; set; }
        public string   SupplierName     { get; set; }  // joined
        public int      OrderedByUserID  { get; set; }
        public string   OrderedBy        { get; set; }  // joined
        public DateTime OrderDate        { get; set; }
        public DateTime? ExpectedDate    { get; set; }
        public DateTime? ReceivedDate    { get; set; }
        public decimal  TotalAmount      { get; set; }
        public string   Status           { get; set; }
        public string   Notes            { get; set; }
    }

    // ── 11. Session (software class) ──────────────────────────────────────────
    public static class Session
    {
        public static User   CurrentUser   { get; set; }
        public static bool   IsLoggedIn    => CurrentUser != null;
        public static string CurrentRole   => CurrentUser?.RoleName ?? "";

        public static void Clear() => CurrentUser = null;

        public static bool HasRole(string role) =>
            string.Equals(CurrentRole, role, StringComparison.OrdinalIgnoreCase);
    }
}
