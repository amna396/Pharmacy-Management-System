using System;
using System.IO;
using MySql.Data.MySqlClient;
using PharmacyMS.DAL;

namespace PharmacyMS
{
    /// <summary>
    /// Centralised error and info logger.
    /// Writes to a daily log file and optionally to the ErrorLogs DB table.
    /// </summary>
    public static class Logger
    {
        private static readonly string LogDir =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");

        static Logger()
        {
            if (!Directory.Exists(LogDir))
                Directory.CreateDirectory(LogDir);
        }

        private static string LogFile =>
            Path.Combine(LogDir, $"PharmacyMS_{DateTime.Now:yyyy-MM-dd}.log");

        // ── Core log method ───────────────────────────────────────────────────
        public static void Log(string severity, string formName,
                               string message, string stackTrace = "")
        {
            try
            {
                string entry =
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{severity}] " +
                    $"[{formName}] {message}";

                if (!string.IsNullOrWhiteSpace(stackTrace))
                    entry += $"\n  StackTrace: {stackTrace}";

                File.AppendAllText(LogFile, entry + Environment.NewLine);

                // Also write to DB (best-effort, don't crash if DB is down)
                try { WriteToDatabase(severity, formName, message, stackTrace); }
                catch { /* swallow DB errors in logger */ }
            }
            catch { /* swallow file-system errors in logger */ }
        }

        // ── Convenience overloads ─────────────────────────────────────────────
        public static void LogError(string formName, string action, Exception ex) =>
            Log("Error", formName,
                $"Action={action} | {ex.Message}", ex.StackTrace);

        public static void LogInfo(string formName, string message) =>
            Log("Info", formName, message);

        public static void LogWarning(string formName, string message) =>
            Log("Warning", formName, message);

        // ── Write to DB ───────────────────────────────────────────────────────
        private static void WriteToDatabase(string severity, string formName,
                                            string message, string stackTrace)
        {
            using (var conn = DBConnection.Instance.GetConnection())
            using (var cmd  = new MySqlCommand(
                "INSERT INTO ErrorLogs (FormName, ErrorMsg, StackTrace, Severity) " +
                "VALUES (@form, @msg, @trace, @sev)", conn))
            {
                cmd.Parameters.AddWithValue("@form",  formName);
                cmd.Parameters.AddWithValue("@msg",   message);
                cmd.Parameters.AddWithValue("@trace", stackTrace ?? "");
                cmd.Parameters.AddWithValue("@sev",   severity);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
