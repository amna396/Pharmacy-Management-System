using System;
using System.Text.RegularExpressions;

namespace PharmacyMS.Utils
{
    /// <summary>
    /// Centralised validators used across all forms.
    /// Each method returns true = valid, false = invalid.
    /// </summary>
    public static class Validator
    {
        // ── String ────────────────────────────────────────────────────────────
        public static bool IsNotEmpty(string value) =>
            !string.IsNullOrWhiteSpace(value);

        public static bool MinLength(string value, int min) =>
            !string.IsNullOrWhiteSpace(value) && value.Trim().Length >= min;

        public static bool MaxLength(string value, int max) =>
            value != null && value.Length <= max;

        // ── Numeric ───────────────────────────────────────────────────────────
        public static bool IsPositiveDecimal(string value, out decimal result)
        {
            if (decimal.TryParse(value, out result))
                return result > 0;
            return false;
        }

        public static bool IsNonNegativeInt(string value, out int result)
        {
            if (int.TryParse(value, out result))
                return result >= 0;
            return false;
        }

        // ── Email ─────────────────────────────────────────────────────────────
        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return false;
            return Regex.IsMatch(email.Trim(),
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                RegexOptions.IgnoreCase);
        }

        // ── Phone ─────────────────────────────────────────────────────────────
        public static bool IsValidPhone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone)) return false;
            return Regex.IsMatch(phone.Trim(), @"^[\d\s\-\+\(\)]{7,20}$");
        }

        // ── Date ──────────────────────────────────────────────────────────────
        public static bool IsFutureDate(DateTime date) =>
            date.Date > DateTime.Today;

        public static bool IsNotFutureDate(DateTime date) =>
            date.Date <= DateTime.Today;

        // ── Password ──────────────────────────────────────────────────────────
        /// <summary>
        /// At least 6 chars, one uppercase, one digit.
        /// </summary>
        public static bool IsStrongPassword(string password)
        {
            if (string.IsNullOrWhiteSpace(password) || password.Length < 6)
                return false;
            bool hasUpper  = Regex.IsMatch(password, "[A-Z]");
            bool hasDigit  = Regex.IsMatch(password, "[0-9]");
            return hasUpper && hasDigit;
        }

        // ── Combo: show error in label ────────────────────────────────────────
        public static bool ValidateField(string value, string fieldName,
                                         out string errorMessage,
                                         int minLen = 1, int maxLen = 255)
        {
            errorMessage = "";
            if (!IsNotEmpty(value))          { errorMessage = $"{fieldName} is required.";                    return false; }
            if (!MinLength(value, minLen))    { errorMessage = $"{fieldName} must be at least {minLen} chars."; return false; }
            if (!MaxLength(value, maxLen))    { errorMessage = $"{fieldName} must be at most {maxLen} chars.";  return false; }
            return true;
        }
    }
}
