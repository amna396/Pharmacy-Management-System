using System;
using System.Security.Cryptography;
using System.Text;

namespace PharmacyMS.Utils
{
    public static class PasswordHelper
    {
        /// <summary>SHA-256 hash — matches SHA2('password', 256) in MySQL.</summary>
        public static string Hash(string password)
        {
            using (var sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                var sb = new StringBuilder();
                foreach (byte b in bytes)
                    sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        public static bool Verify(string plainText, string hash) =>
            string.Equals(Hash(plainText), hash, StringComparison.OrdinalIgnoreCase);
    }
}
