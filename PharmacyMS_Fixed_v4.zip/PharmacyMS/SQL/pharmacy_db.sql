-- ============================================================
--  PHARMACY MANAGEMENT SYSTEM - DATABASE SCRIPT
--  Database: MySQL
--  Project:  DBS26IST2ndAF (Semester Final Project)
-- ============================================================

DROP DATABASE IF EXISTS PharmacyMS;
CREATE DATABASE PharmacyMS CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE PharmacyMS;

-- ============================================================
--  TABLES (15+)
-- ============================================================

-- 1. Roles
CREATE TABLE Roles (
    RoleID      INT AUTO_INCREMENT PRIMARY KEY,
    RoleName    VARCHAR(50)  NOT NULL UNIQUE,
    Description VARCHAR(255),
    CreatedAt   DATETIME     DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_rolename CHECK (CHAR_LENGTH(RoleName) >= 2)
);

-- 2. Users
CREATE TABLE Users (
    UserID       INT AUTO_INCREMENT PRIMARY KEY,
    Username     VARCHAR(50)  NOT NULL UNIQUE,
    PasswordHash VARCHAR(256) NOT NULL,
    FullName     VARCHAR(100) NOT NULL,
    Email        VARCHAR(100) NOT NULL UNIQUE,
    Phone        VARCHAR(20),
    RoleID       INT          NOT NULL,
    IsActive     TINYINT(1)   NOT NULL DEFAULT 1,
    CreatedAt    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    LastLogin    DATETIME,
    CONSTRAINT fk_users_role   FOREIGN KEY (RoleID) REFERENCES Roles(RoleID),
    CONSTRAINT chk_email       CHECK (Email LIKE '%@%.%'),
    CONSTRAINT chk_username    CHECK (CHAR_LENGTH(Username) >= 4)
);

-- 3. Suppliers
CREATE TABLE Suppliers (
    SupplierID   INT AUTO_INCREMENT PRIMARY KEY,
    SupplierName VARCHAR(100) NOT NULL,
    ContactName  VARCHAR(100),
    Email        VARCHAR(100),
    Phone        VARCHAR(20)  NOT NULL,
    Address      TEXT,
    City         VARCHAR(50),
    Country      VARCHAR(50)  DEFAULT 'Pakistan',
    IsActive     TINYINT(1)   DEFAULT 1,
    CreatedAt    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_supplier_phone CHECK (CHAR_LENGTH(Phone) >= 7)
);

-- 4. Categories
CREATE TABLE Categories (
    CategoryID   INT AUTO_INCREMENT PRIMARY KEY,
    CategoryName VARCHAR(100) NOT NULL UNIQUE,
    Description  TEXT,
    IsActive     TINYINT(1)   DEFAULT 1
);

-- 5. Medicines
CREATE TABLE Medicines (
    MedicineID      INT AUTO_INCREMENT PRIMARY KEY,
    MedicineName    VARCHAR(150) NOT NULL,
    GenericName     VARCHAR(150),
    CategoryID      INT          NOT NULL,
    SupplierID      INT,
    UnitPrice       DECIMAL(10,2) NOT NULL,
    SalePrice       DECIMAL(10,2) NOT NULL,
    StockQuantity   INT           NOT NULL DEFAULT 0,
    ReorderLevel    INT           NOT NULL DEFAULT 10,
    UnitOfMeasure   VARCHAR(30)   DEFAULT 'Tablets',
    RequiresPrescription TINYINT(1) DEFAULT 0,
    ShelfLocation   VARCHAR(50),
    IsActive        TINYINT(1)   DEFAULT 1,
    CreatedAt       DATETIME     DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_med_category  FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID),
    CONSTRAINT fk_med_supplier  FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID),
    CONSTRAINT chk_unit_price   CHECK (UnitPrice >= 0),
    CONSTRAINT chk_sale_price   CHECK (SalePrice >= 0),
    CONSTRAINT chk_stock        CHECK (StockQuantity >= 0)
);

-- 6. Customers
CREATE TABLE Customers (
    CustomerID   INT AUTO_INCREMENT PRIMARY KEY,
    FullName     VARCHAR(100) NOT NULL,
    Phone        VARCHAR(20),
    Email        VARCHAR(100),
    Address      TEXT,
    DateOfBirth  DATE,
    Gender       ENUM('Male','Female','Other'),
    MedicalNotes TEXT,
    CreatedAt    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 7. Prescriptions
CREATE TABLE Prescriptions (
    PrescriptionID  INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID      INT NOT NULL,
    DoctorName      VARCHAR(100),
    DoctorPhone     VARCHAR(20),
    IssuedDate      DATE NOT NULL,
    ExpiryDate      DATE,
    Notes           TEXT,
    ScannedFilePath VARCHAR(500),
    CreatedAt       DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_presc_customer FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    CONSTRAINT chk_presc_dates   CHECK (ExpiryDate IS NULL OR ExpiryDate >= IssuedDate)
);

-- 8. Sales (Header)
CREATE TABLE Sales (
    SaleID        INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID    INT,
    UserID        INT          NOT NULL,
    PrescriptionID INT,
    SaleDate      DATETIME     DEFAULT CURRENT_TIMESTAMP,
    TotalAmount   DECIMAL(10,2) NOT NULL DEFAULT 0,
    DiscountAmount DECIMAL(10,2) NOT NULL DEFAULT 0,
    NetAmount     DECIMAL(10,2) NOT NULL DEFAULT 0,
    PaymentMethod ENUM('Cash','Card','Bank Transfer') DEFAULT 'Cash',
    PaymentStatus ENUM('Paid','Pending','Refunded') DEFAULT 'Paid',
    Notes         TEXT,
    CONSTRAINT fk_sale_customer FOREIGN KEY (CustomerID)     REFERENCES Customers(CustomerID),
    CONSTRAINT fk_sale_user     FOREIGN KEY (UserID)         REFERENCES Users(UserID),
    CONSTRAINT fk_sale_presc    FOREIGN KEY (PrescriptionID) REFERENCES Prescriptions(PrescriptionID),
    CONSTRAINT chk_total        CHECK (TotalAmount >= 0),
    CONSTRAINT chk_discount     CHECK (DiscountAmount >= 0),
    CONSTRAINT chk_net          CHECK (NetAmount >= 0)
);

-- 9. SaleItems (Detail)
CREATE TABLE SaleItems (
    SaleItemID  INT AUTO_INCREMENT PRIMARY KEY,
    SaleID      INT           NOT NULL,
    MedicineID  INT           NOT NULL,
    Quantity    INT           NOT NULL,
    UnitPrice   DECIMAL(10,2) NOT NULL,
    Discount    DECIMAL(5,2)  DEFAULT 0,
    SubTotal    DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_si_sale      FOREIGN KEY (SaleID)      REFERENCES Sales(SaleID),
    CONSTRAINT fk_si_medicine  FOREIGN KEY (MedicineID)  REFERENCES Medicines(MedicineID),
    CONSTRAINT chk_si_qty      CHECK (Quantity > 0),
    CONSTRAINT chk_si_price    CHECK (UnitPrice >= 0)
);

-- 10. PurchaseOrders (Header)
CREATE TABLE PurchaseOrders (
    POID          INT AUTO_INCREMENT PRIMARY KEY,
    SupplierID    INT           NOT NULL,
    OrderedByUserID INT         NOT NULL,
    OrderDate     DATETIME      DEFAULT CURRENT_TIMESTAMP,
    ExpectedDate  DATE,
    ReceivedDate  DATE,
    TotalAmount   DECIMAL(10,2) DEFAULT 0,
    Status        ENUM('Pending','Approved','Received','Cancelled') DEFAULT 'Pending',
    Notes         TEXT,
    CONSTRAINT fk_po_supplier FOREIGN KEY (SupplierID)       REFERENCES Suppliers(SupplierID),
    CONSTRAINT fk_po_user     FOREIGN KEY (OrderedByUserID)  REFERENCES Users(UserID)
);

-- 11. PurchaseOrderItems (Detail)
CREATE TABLE PurchaseOrderItems (
    POItemID    INT AUTO_INCREMENT PRIMARY KEY,
    POID        INT           NOT NULL,
    MedicineID  INT           NOT NULL,
    Quantity    INT           NOT NULL,
    UnitCost    DECIMAL(10,2) NOT NULL,
    SubTotal    DECIMAL(10,2) NOT NULL,
    ExpiryDate  DATE,
    BatchNumber VARCHAR(50),
    CONSTRAINT fk_poi_po       FOREIGN KEY (POID)        REFERENCES PurchaseOrders(POID),
    CONSTRAINT fk_poi_medicine FOREIGN KEY (MedicineID)  REFERENCES Medicines(MedicineID),
    CONSTRAINT chk_poi_qty     CHECK (Quantity > 0)
);

-- 12. Inventory (Batch-level stock)
CREATE TABLE Inventory (
    InventoryID  INT AUTO_INCREMENT PRIMARY KEY,
    MedicineID   INT          NOT NULL,
    BatchNumber  VARCHAR(50),
    Quantity     INT          NOT NULL DEFAULT 0,
    ExpiryDate   DATE,
    ReceivedDate DATE         DEFAULT (CURRENT_DATE),
    UnitCost     DECIMAL(10,2),
    CONSTRAINT fk_inv_medicine FOREIGN KEY (MedicineID) REFERENCES Medicines(MedicineID),
    CONSTRAINT chk_inv_qty     CHECK (Quantity >= 0)
);

-- 13. ErrorLogs
CREATE TABLE ErrorLogs (
    LogID       INT AUTO_INCREMENT PRIMARY KEY,
    UserID      INT,
    FormName    VARCHAR(100),
    ErrorMsg    TEXT         NOT NULL,
    StackTrace  TEXT,
    LoggedAt    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    Severity    ENUM('Info','Warning','Error','Critical') DEFAULT 'Error',
    CONSTRAINT fk_log_user FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- 14. AuditTrail
CREATE TABLE AuditTrail (
    AuditID     INT AUTO_INCREMENT PRIMARY KEY,
    UserID      INT,
    TableName   VARCHAR(100) NOT NULL,
    RecordID    INT,
    Action      ENUM('INSERT','UPDATE','DELETE') NOT NULL,
    OldValue    TEXT,
    NewValue    TEXT,
    ActionTime  DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_user FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- 15. Settings
CREATE TABLE Settings (
    SettingID   INT AUTO_INCREMENT PRIMARY KEY,
    SettingKey  VARCHAR(100) NOT NULL UNIQUE,
    SettingValue TEXT,
    Description VARCHAR(255)
);

-- 16. Returns
CREATE TABLE Returns (
    ReturnID      INT AUTO_INCREMENT PRIMARY KEY,
    SaleID        INT          NOT NULL,
    MedicineID    INT          NOT NULL,
    Quantity      INT          NOT NULL,
    Reason        TEXT,
    RefundAmount  DECIMAL(10,2),
    ProcessedBy   INT          NOT NULL,
    ReturnDate    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ret_sale     FOREIGN KEY (SaleID)      REFERENCES Sales(SaleID),
    CONSTRAINT fk_ret_medicine FOREIGN KEY (MedicineID)  REFERENCES Medicines(MedicineID),
    CONSTRAINT fk_ret_user     FOREIGN KEY (ProcessedBy) REFERENCES Users(UserID),
    CONSTRAINT chk_ret_qty     CHECK (Quantity > 0)
);

-- ============================================================
--  VIEWS (5+)
-- ============================================================

-- View 1: Low stock medicines
CREATE VIEW vw_LowStockMedicines AS
SELECT m.MedicineID, m.MedicineName, m.GenericName,
       c.CategoryName, m.StockQuantity, m.ReorderLevel,
       m.SalePrice, s.SupplierName, s.Phone AS SupplierPhone
FROM   Medicines m
JOIN   Categories c ON m.CategoryID = c.CategoryID
LEFT JOIN Suppliers s ON m.SupplierID = s.SupplierID
WHERE  m.StockQuantity <= m.ReorderLevel AND m.IsActive = 1;

-- View 2: Daily sales summary
CREATE VIEW vw_DailySalesSummary AS
SELECT DATE(SaleDate)      AS SaleDay,
       COUNT(*)            AS TotalTransactions,
       SUM(NetAmount)      AS TotalRevenue,
       SUM(DiscountAmount) AS TotalDiscount,
       AVG(NetAmount)      AS AvgSaleValue
FROM   Sales
WHERE  PaymentStatus != 'Refunded'
GROUP BY DATE(SaleDate);

-- View 3: Medicine sales performance
CREATE VIEW vw_MedicineSalesPerformance AS
SELECT m.MedicineID, m.MedicineName, c.CategoryName,
       SUM(si.Quantity)  AS TotalSold,
       SUM(si.SubTotal)  AS TotalRevenue,
       COUNT(DISTINCT si.SaleID) AS NumberOfSales
FROM   Medicines m
JOIN   Categories c  ON m.CategoryID = c.CategoryID
JOIN   SaleItems si  ON m.MedicineID = si.MedicineID
JOIN   Sales s       ON si.SaleID    = s.SaleID
WHERE  s.PaymentStatus != 'Refunded'
GROUP BY m.MedicineID, m.MedicineName, c.CategoryName;

-- View 4: Expiring medicines (next 90 days)
CREATE VIEW vw_ExpiringMedicines AS
SELECT m.MedicineID, m.MedicineName, i.BatchNumber,
       i.Quantity, i.ExpiryDate,
       DATEDIFF(i.ExpiryDate, CURDATE()) AS DaysToExpiry,
       s.SupplierName
FROM   Inventory i
JOIN   Medicines m ON i.MedicineID = m.MedicineID
LEFT JOIN Suppliers s ON m.SupplierID = s.SupplierID
WHERE  i.ExpiryDate BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 90 DAY)
ORDER BY i.ExpiryDate;

-- View 5: Customer purchase history
CREATE VIEW vw_CustomerPurchaseHistory AS
SELECT c.CustomerID, c.FullName, c.Phone,
       s.SaleID, s.SaleDate, s.NetAmount, s.PaymentMethod,
       COUNT(si.SaleItemID) AS ItemCount
FROM   Customers c
JOIN   Sales s    ON c.CustomerID = s.CustomerID
JOIN   SaleItems si ON s.SaleID  = si.SaleID
GROUP BY c.CustomerID, c.FullName, c.Phone, s.SaleID, s.SaleDate, s.NetAmount, s.PaymentMethod;

-- View 6: Purchase order status overview
CREATE VIEW vw_PurchaseOrderOverview AS
SELECT po.POID, po.OrderDate, po.Status,
       su.SupplierName, u.FullName AS OrderedBy,
       po.TotalAmount, po.ExpectedDate, po.ReceivedDate,
       COUNT(poi.POItemID) AS TotalItems
FROM   PurchaseOrders po
JOIN   Suppliers su ON po.SupplierID = su.SupplierID
JOIN   Users u      ON po.OrderedByUserID = u.UserID
LEFT JOIN PurchaseOrderItems poi ON po.POID = poi.POID
GROUP BY po.POID, po.OrderDate, po.Status, su.SupplierName, u.FullName, po.TotalAmount, po.ExpectedDate, po.ReceivedDate;

-- ============================================================
--  STORED PROCEDURES (3+)
-- ============================================================

DELIMITER $$

-- SP 1: Process a complete sale with stock update (uses transaction)
CREATE PROCEDURE sp_ProcessSale(
    IN  p_CustomerID     INT,
    IN  p_UserID         INT,
    IN  p_PrescriptionID INT,
    IN  p_PaymentMethod  VARCHAR(20),
    IN  p_Discount       DECIMAL(10,2),
    IN  p_MedicineIDs    TEXT,   -- comma-separated medicine IDs
    IN  p_Quantities     TEXT,   -- comma-separated quantities
    OUT p_SaleID         INT,
    OUT p_Message        VARCHAR(200)
)
BEGIN
    DECLARE v_Total     DECIMAL(10,2) DEFAULT 0;
    DECLARE v_NetAmount DECIMAL(10,2);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_SaleID  = -1;
        SET p_Message = 'Error processing sale. Transaction rolled back.';
    END;

    START TRANSACTION;

    -- Insert sale header
    INSERT INTO Sales (CustomerID, UserID, PrescriptionID, PaymentMethod, DiscountAmount, TotalAmount, NetAmount)
    VALUES (p_CustomerID, p_UserID, p_PrescriptionID, p_PaymentMethod, p_Discount, 0, 0);

    SET p_SaleID = LAST_INSERT_ID();

    -- Actual line items are inserted by the application layer via parameterised inserts
    -- This SP finalises totals and deducts stock

    -- Recalculate totals
    SELECT COALESCE(SUM(SubTotal), 0) INTO v_Total
    FROM SaleItems WHERE SaleID = p_SaleID;

    SET v_NetAmount = v_Total - COALESCE(p_Discount, 0);

    UPDATE Sales
    SET TotalAmount   = v_Total,
        DiscountAmount = COALESCE(p_Discount, 0),
        NetAmount     = v_NetAmount
    WHERE SaleID = p_SaleID;

    -- Deduct stock for each sale item
    UPDATE Medicines m
    JOIN SaleItems si ON m.MedicineID = si.MedicineID
    SET m.StockQuantity = m.StockQuantity - si.Quantity
    WHERE si.SaleID = p_SaleID;

    COMMIT;
    SET p_Message = 'Sale processed successfully.';
END$$

-- SP 2: Receive purchase order and update inventory
CREATE PROCEDURE sp_ReceivePurchaseOrder(
    IN  p_POID   INT,
    IN  p_UserID INT,
    OUT p_Message VARCHAR(200)
)
BEGIN
    DECLARE v_Status VARCHAR(20);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_Message = 'Error receiving order. Transaction rolled back.';
    END;

    SELECT Status INTO v_Status FROM PurchaseOrders WHERE POID = p_POID;

    IF v_Status != 'Approved' THEN
        SET p_Message = 'Order must be Approved before receiving.';
    ELSE
        START TRANSACTION;

        -- Update order status
        UPDATE PurchaseOrders
        SET Status = 'Received', ReceivedDate = CURDATE()
        WHERE POID = p_POID;

        -- Update medicine stock levels
        UPDATE Medicines m
        JOIN PurchaseOrderItems poi ON m.MedicineID = poi.MedicineID
        SET m.StockQuantity = m.StockQuantity + poi.Quantity
        WHERE poi.POID = p_POID;

        -- Insert inventory batch records
        INSERT INTO Inventory (MedicineID, BatchNumber, Quantity, ExpiryDate, ReceivedDate, UnitCost)
        SELECT MedicineID, BatchNumber, Quantity, ExpiryDate, CURDATE(), UnitCost
        FROM PurchaseOrderItems
        WHERE POID = p_POID;

        COMMIT;
        SET p_Message = 'Purchase order received and stock updated.';
    END IF;
END$$

-- SP 3: Generate monthly sales report
CREATE PROCEDURE sp_MonthlySalesReport(
    IN p_Year  INT,
    IN p_Month INT
)
BEGIN
    SELECT
        s.SaleID,
        s.SaleDate,
        COALESCE(c.FullName, 'Walk-in') AS CustomerName,
        u.FullName  AS CashierName,
        s.TotalAmount,
        s.DiscountAmount,
        s.NetAmount,
        s.PaymentMethod,
        s.PaymentStatus,
        COUNT(si.SaleItemID) AS ItemCount
    FROM Sales s
    LEFT JOIN Customers c ON s.CustomerID = c.CustomerID
    JOIN Users u           ON s.UserID     = u.UserID
    JOIN SaleItems si      ON s.SaleID     = si.SaleID
    WHERE YEAR(s.SaleDate)  = p_Year
      AND MONTH(s.SaleDate) = p_Month
    GROUP BY s.SaleID, s.SaleDate, CustomerName, u.FullName,
             s.TotalAmount, s.DiscountAmount, s.NetAmount,
             s.PaymentMethod, s.PaymentStatus
    ORDER BY s.SaleDate;
END$$

-- SP 4: Search medicines
CREATE PROCEDURE sp_SearchMedicines(
    IN p_SearchTerm VARCHAR(100),
    IN p_CategoryID INT
)
BEGIN
    SELECT m.MedicineID, m.MedicineName, m.GenericName,
           c.CategoryName, m.SalePrice, m.StockQuantity,
           m.UnitOfMeasure, m.RequiresPrescription
    FROM Medicines m
    JOIN Categories c ON m.CategoryID = c.CategoryID
    WHERE m.IsActive = 1
      AND (p_SearchTerm IS NULL OR m.MedicineName LIKE CONCAT('%', p_SearchTerm, '%')
           OR m.GenericName LIKE CONCAT('%', p_SearchTerm, '%'))
      AND (p_CategoryID IS NULL OR m.CategoryID = p_CategoryID)
    ORDER BY m.MedicineName;
END$$

DELIMITER ;

-- ============================================================
--  TRIGGERS (2+)
-- ============================================================

DELIMITER $$

-- Trigger 1: Prevent sale if stock is insufficient
CREATE TRIGGER trg_CheckStock_BeforeInsert
BEFORE INSERT ON SaleItems
FOR EACH ROW
BEGIN
    DECLARE v_Stock INT;
    SELECT StockQuantity INTO v_Stock
    FROM Medicines WHERE MedicineID = NEW.MedicineID;
    IF v_Stock < NEW.Quantity THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Insufficient stock for this medicine.';
    END IF;
END$$

-- Trigger 2: Audit trail on Medicines update
CREATE TRIGGER trg_Audit_Medicine_Update
AFTER UPDATE ON Medicines
FOR EACH ROW
BEGIN
    INSERT INTO AuditTrail (TableName, RecordID, Action, OldValue, NewValue)
    VALUES (
        'Medicines',
        OLD.MedicineID,
        'UPDATE',
        CONCAT('Name=', OLD.MedicineName, ', Stock=', OLD.StockQuantity, ', Price=', OLD.SalePrice),
        CONCAT('Name=', NEW.MedicineName, ', Stock=', NEW.StockQuantity, ', Price=', NEW.SalePrice)
    );
END$$

-- Trigger 3: Auto-recalculate sale total after item insert
CREATE TRIGGER trg_UpdateSaleTotal_AfterInsert
AFTER INSERT ON SaleItems
FOR EACH ROW
BEGIN
    UPDATE Sales
    SET TotalAmount = (SELECT COALESCE(SUM(SubTotal),0) FROM SaleItems WHERE SaleID = NEW.SaleID),
        NetAmount   = TotalAmount - DiscountAmount
    WHERE SaleID = NEW.SaleID;
END$$

DELIMITER ;

-- ============================================================
--  SEED DATA
-- ============================================================

-- Roles
INSERT INTO Roles (RoleName, Description) VALUES
('Admin',      'Full system access'),
('Pharmacist', 'Manage sales and prescriptions'),
('Manager',    'Reports and purchase orders'),
('Cashier',    'Sales only');

-- Default admin user (password: Admin@123 – hashed with SHA2-256 in app)
INSERT INTO Users (Username, PasswordHash, FullName, Email, Phone, RoleID) VALUES
('admin', SHA2('Admin@123', 256), 'System Administrator', 'admin@pharmacy.com', '03001234567', 1),
('john_pharma', SHA2('John@123', 256), 'John Ahmed', 'john@pharmacy.com', '03011234567', 2),
('sara_mgr',    SHA2('Sara@123', 256), 'Sara Khan',  'sara@pharmacy.com', '03021234567', 3);

-- Categories
INSERT INTO Categories (CategoryName, Description) VALUES
('Antibiotics',       'Medicines that fight bacterial infections'),
('Analgesics',        'Pain relief medicines'),
('Antacids',          'Medicines for acidity and heartburn'),
('Vitamins',          'Vitamin and supplement products'),
('Antihistamines',    'Allergy relief medicines'),
('Cardiovascular',    'Heart and blood pressure medicines'),
('Diabetes',          'Medicines for diabetes management'),
('Dermatology',       'Skin care medicines and creams'),
('Respiratory',       'Asthma and respiratory medicines'),
('Gastrointestinal',  'Digestive system medicines');

-- Suppliers
INSERT INTO Suppliers (SupplierName, ContactName, Email, Phone, Address, City) VALUES
('MedPharma Distributors',  'Ali Raza',     'ali@medpharma.pk',    '04235678901', '12 Industrial Area',  'Lahore'),
('Getz Pharma',             'Sana Malik',   'sana@getz.pk',        '02134567890', '5 Clifton Block 4',   'Karachi'),
('Ferozsons Laboratories',  'Usman Shah',   'usman@ferozsons.pk',  '05145678901', 'GT Road',             'Rawalpindi'),
('Abbott Pakistan',         'Hina Baig',    'hina@abbott.pk',      '04256789012', 'Phase 5 DHA',         'Lahore'),
('Highnoon Laboratories',   'Tariq Ahmed',  'tariq@highnoon.pk',   '04267890123', 'Sundar Industrial',   'Lahore');

-- Medicines
INSERT INTO Medicines (MedicineName, GenericName, CategoryID, SupplierID, UnitPrice, SalePrice, StockQuantity, ReorderLevel, UnitOfMeasure, RequiresPrescription) VALUES
('Augmentin 625mg',    'Amoxicillin+Clavulanic Acid', 1, 1, 180, 220, 200, 20, 'Tablets',  1),
('Panadol Extra',      'Paracetamol+Caffeine',        2, 2,  25,  35, 500, 50, 'Tablets',  0),
('Brufen 400mg',       'Ibuprofen',                   2, 3,  30,  45, 350, 30, 'Tablets',  0),
('Gaviscon Liquid',    'Sodium Alginate',             3, 4,  95, 130, 120, 15, 'Syrup',    0),
('Centrum Advance',    'Multivitamins',               4, 5, 550, 680, 150, 20, 'Tablets',  0),
('Cetirizine 10mg',    'Cetirizine HCl',              5, 1,  15,  25, 400, 40, 'Tablets',  0),
('Concor 5mg',         'Bisoprolol',                  6, 2, 120, 165, 180, 20, 'Tablets',  1),
('Glucophage 500mg',   'Metformin HCl',               7, 3,  55,  80, 250, 25, 'Tablets',  1),
('Betnovate Cream',    'Betamethasone',               8, 4, 145, 195,  90, 10, 'Cream',    1),
('Ventolin Inhaler',   'Salbutamol',                  9, 5, 350, 420,  75, 10, 'Inhaler',  1),
('Flagyl 400mg',       'Metronidazole',               1, 1,  45,  65, 300, 30, 'Tablets',  1),
('Omeprazole 20mg',    'Omeprazole',                  3, 2,  40,  60, 320, 35, 'Capsules', 0),
('Vitamin C 500mg',    'Ascorbic Acid',               4, 3,  35,  50, 420, 40, 'Tablets',  0),
('Loratadine 10mg',    'Loratadine',                  5, 4,  20,  30, 380, 35, 'Tablets',  0),
('Crestor 10mg',       'Rosuvastatin',                6, 5, 280, 350, 110, 15, 'Tablets',  1);

-- Customers
INSERT INTO Customers (FullName, Phone, Email, Gender) VALUES
('Ahmed Hassan',    '03001111111', 'ahmed@gmail.com',  'Male'),
('Fatima Noor',     '03012222222', 'fatima@gmail.com', 'Female'),
('Usman Tariq',     '03023333333', NULL,               'Male'),
('Ayesha Siddiqui', '03034444444', 'ayesha@yahoo.com', 'Female'),
('Bilal Akhtar',    '03045555555', NULL,               'Male');

-- Settings
INSERT INTO Settings (SettingKey, SettingValue, Description) VALUES
('PharmacyName',    'CureWell Pharmacy',         'Name shown on receipts'),
('PharmacyAddress', '123 Main Street, Lahore',   'Address shown on receipts'),
('PharmacyPhone',   '042-35678901',              'Contact number'),
('TaxRate',         '0',                          'Sales tax percentage'),
('ReceiptFooter',   'Thank you for your trust!', 'Footer message on receipts'),
('LowStockAlert',   '1',                          'Enable low stock notifications');

-- ============================================================
--  USEFUL QUERIES FOR TESTING
-- ============================================================

-- Check low stock
SELECT * FROM vw_LowStockMedicines;

-- Today's sales
SELECT * FROM vw_DailySalesSummary WHERE SaleDay = CURDATE();

-- Expiring soon
SELECT * FROM vw_ExpiringMedicines;

-- Call stored procedure
CALL sp_SearchMedicines('panadol', NULL);
CALL sp_MonthlySalesReport(2026, 6);

SELECT 'PharmacyMS database created successfully!' AS Status;
